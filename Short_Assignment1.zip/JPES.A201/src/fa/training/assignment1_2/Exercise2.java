/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 15 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.assignment1_2;

import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int firstNum = in.nextInt(),
			secondNum = in.nextInt(),
			thirdNum = in.nextInt(),
			fourthNum = in.nextInt();
		if (firstNum==secondNum && secondNum==thirdNum && thirdNum==fourthNum) {
			System.out.println("Numbers are equal!");
		} else {
			System.out.println("Numbers are not equal!");
		}
	}

}
