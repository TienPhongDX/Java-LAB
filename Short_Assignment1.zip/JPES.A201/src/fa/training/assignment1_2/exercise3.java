/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 15 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.assignment1_2;

import java.util.Scanner;

public class exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int firstNum = in.nextInt(),
			secondNum = in.nextInt(),
			thirdNum = in.nextInt(),
			fourthNum = in.nextInt();
		int sum = firstNum+secondNum+thirdNum+fourthNum;
		System.out.println("The sum is "+ sum);
	}

}
