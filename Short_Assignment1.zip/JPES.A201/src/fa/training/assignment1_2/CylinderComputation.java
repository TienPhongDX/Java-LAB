/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 15 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.assignment1_2;

public class CylinderComputation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double radius = 20.5,
			   height = 16.6,
			   surfaceArea,
			   baseArea,
			   volume;
		
		surfaceArea = 2*Math.PI*radius*height + 2*Math.PI*radius*radius;
		baseArea = Math.PI*radius*radius;
		volume = Math.PI*radius*radius*height;
		System.out.println("Surface area = "+surfaceArea+"\n"+
						   "Base area = "+baseArea+"\n"+
				           "Volume = "+volume);
	}

}
