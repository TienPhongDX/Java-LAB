/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 15 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.assignment1_2;

public class exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("101 + 0) / 3 -> "+ ((101 + 0) / 3) +"\n"+
				"3.0e-6 * 10000000.1 -> " + (3.0e-6 * 10000000.1)+"\n"+
				"true && true -> "+(true && true) + "\n"+
				"false && true -> "+(false && true) +"\n"+
				"(false && false) || (true && true)"+((false && false) || (true && true)) +"\n"+
				"(false || false) && (true && true)"+((false || false) && (true && true))
				);
	}

}
