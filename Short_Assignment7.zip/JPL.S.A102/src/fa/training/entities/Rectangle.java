/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public class Rectangle implements Shape{
	private int length;
	private int width;
	
	public Rectangle() {
		super();
	}
	
	public Rectangle(int length, int width) {
		super();
		this.length = length;
		this.width = width;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	@Override
	public int calculatePerimeter() {
		// TODO Auto-generated method stub
		return 2*(length+width);
	}

	@Override
	public int calculateArea() {
		// TODO Auto-generated method stub
		return length*width;
	}

	@Override
	public int getLength() {
		// TODO Auto-generated method stub
		return length;
	}

	@Override
	public int getWidth() {
		// TODO Auto-generated method stub
		return width;
	}

	@Override
	public void setLengthWidth(int length, int width) {
		// TODO Auto-generated method stub
		this.length = length;
		this.width = width;
	}

	@Override
	public String toString() {
		return "Rectangle [length=" + length + ", width=" + width + "]";
	}
	
	

}
