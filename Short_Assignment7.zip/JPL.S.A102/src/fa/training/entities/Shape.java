/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public interface Shape {
	abstract int calculatePerimeter();
	abstract int calculateArea();
	abstract int getLength();
	abstract int getWidth();
	abstract void setLengthWidth(int length, int width);
	
}
