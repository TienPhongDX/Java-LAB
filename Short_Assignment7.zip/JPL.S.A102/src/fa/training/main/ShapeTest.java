/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import java.util.Scanner;

import fa.training.entities.Rectangle;

public class ShapeTest {

	final static Scanner k = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO code application logic here
		System.out.print("Enter the size of array: ");
		int n = checkInputLimit();
		int maxArea = 0, minPerimeter = 0, indexMax = 0, indexMin = 0;

		Rectangle[] rec = new Rectangle[n];

		for (int i = 0; i < n; i++) {
			System.out.println("\nRectangle " + (i + 1));
			System.out.print("Enter length: ");
			int len = checkInputLimit();
			System.out.print("Enter width: ");
			int width = checkInputLimit();
			while (width > len) {
				System.err.println("Width cannot be greater than length!");
				System.out.print("Enter again: ");
				width = checkInputLimit();
			}
			rec[i] = new Rectangle(len, width);
			System.out.println("New rectangle added!");
		}

		for (int i = 0; i < n; i++) {
			System.out.print("\n\nRectangle " + (i + 1) + ":");
			rec[i].toString();
			if (i == 0) {
				maxArea = rec[i].calculateArea();
				minPerimeter = rec[i].calculatePerimeter();
				indexMax = i;
				indexMin = i;
			} else {
				if (rec[i].calculateArea() > maxArea) {
					maxArea = rec[i].calculateArea();
					indexMax = i;
				}
				if (rec[i].calculatePerimeter() < minPerimeter) {
					minPerimeter = rec[i].calculatePerimeter();
					indexMin = i;
				}
			}
		}

		System.out.println("\nRectangle has the maximum area:");
		System.out.println("Rectangle " + (indexMax + 1));
		rec[indexMax].toString();

		System.out.println("\nRectangle has the minimum perimeter:");
		System.out.println("Rectangle " + (indexMin + 1));
		rec[indexMin].toString();
	}

	public static int checkInputLimit() {
		while (true) {
			int result = Integer.parseInt(k.nextLine().trim());
			if (result > 0)
				return result;
			else {
				System.err.println("Please input a number > 0!");
				System.out.print("Enter again: ");
			}
		}
	}

}
