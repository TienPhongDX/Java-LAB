/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 23 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Validator {
public final static Scanner in = new Scanner(System.in);
    
    public static int checkInputInt() {
        while (true) {
            try {
                int result = Integer.parseInt(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be integer! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static double checkInputDouble() {
        while (true) {
            try {
                double result = Double.parseDouble(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be double! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    public static Date checkInputDate() {
        DateFormat ft = new SimpleDateFormat ("dd/MM/yyyy");    
        ft.setLenient(false);
        while (true) {
            try {
                Date result = ft.parse(in.nextLine().trim());
                return result;
            } catch (ParseException e) {
                System.err.println("Inputted string must be a date (dd/MM/yyyy)! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static String checkInputString() {
        while(true){
            String result = in.nextLine().trim();
            if (result.isEmpty()){
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static int checkInputLimit(int min, int max){
        while(true){
            int result = Integer.parseInt(in.nextLine().trim());
            if (result >= min && result <= max) return result;
            else{
                System.err.println("Please input number from "+min+" to "+max+"!");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static int checkInputPositive(){
        while(true){
            int result = Integer.parseInt(in.nextLine().trim());
            if (result > 0) return result;
            else{
                System.err.println("Please input a number > 0!");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static String checkValidPhoneNumber() {
        //String regex = "/(0)+([0-9]{9,9})/$";
        while(true){
            String result = checkInputString();
            if (result.length() != 10) {
                System.err.println("Please input valid phone number! (10 digits and starts with 0)");
                System.out.print("Enter again: ");
            }
            else if (result.charAt(0) != '0' || !result.substring(1).matches("\\d+")) {
                System.err.println("Please input valid phone number! (10 digits and starts with 0)");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkValidOrderNumber() {
        //String regex = "/[0-9]{10}/";
        while(true){
            String result = checkInputString();
            if (result.length() != 10) {
                System.err.println("Please input valid order number! (number string with length equals 10)");
                System.out.print("Enter again: ");
            }
            else if (!result.matches("\\d+")) {
                System.err.println("Please input valid order number! (number string with length equals 10)");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static boolean checkInputYN() {
        while (true) {
            String result = Validator.checkInputString();
            if (result.equalsIgnoreCase("Y")) return true;
            else if (result.equalsIgnoreCase("N")) return false;
        System.err.println("Please input y/Y or n/N.");
        System.out.print("Enter again: ");
        }
    }
}
