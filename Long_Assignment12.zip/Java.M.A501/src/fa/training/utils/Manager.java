/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 23 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import fa.training.entities.Customer;
import fa.training.entities.Order;

public class Manager {
	public List<Customer> createCustomer() {
        List<Customer> customer = new ArrayList<>();
        boolean checkCustomer = true;
        while (checkCustomer) {
            System.out.print("Enter customer's name: ");
            String name = Validator.checkInputString();
            System.out.print("Enter customer's phone number: ");
            String phone = Validator.checkValidPhoneNumber();
            System.out.print("Enter customer's address: ");
            String address = Validator.checkInputString();
            boolean checkOrder = true;
            List<Order> order = new ArrayList<>();
            while (checkOrder) {
                System.out.println("Enter order info: ");
                System.out.print("+ Order number: ");
                String number = Validator.checkValidOrderNumber();
                System.out.print("+ Date: ");
                Date date = Validator.checkInputDate();
                Order o = new Order(number, date);
                order.add(o);
                System.out.print("Do you want to add 1 more order? (Y/y: Yes - N/n: no) ");
                checkOrder = Validator.checkInputYN();
            }
            Customer c = new Customer(name, phone, address, order);
            customer.add(c);
            System.out.print("Do you want to add 1 more customer? (Y/y: Yes - N/n: no) ");
            checkCustomer = Validator.checkInputYN();
        }
        return customer;
    }
    
    public void save(List<Customer> customer) {
        File file = new File("customer.dat");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file);
            for (Customer c : customer) {
                String data = c.toString();
                fw.write(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println("File is saved!!");
    }
    
    public void findAll(List<Customer> list) {
        if (list.isEmpty()) System.out.println("The list is empty!");
        else {
            for (Customer customer : list) {
                System.out.println(customer);
            }
        }
    }
    
    public void display(List<Customer> list) {
        if (list.isEmpty()) System.out.println("The list is empty!");
        else {
            System.out.printf("%-20s%-20s%-20s%s", "Customer Name", "Address", "Phone Number", "Order List");
            System.out.println("");
            for (Customer customer : list) {
                System.out.printf("%-20s%-20s%-20s%s", customer.getName(), customer.getAddress(), customer.getPhoneNumber(), customer.getList());
                System.out.println("");
            }
        }
    }
    
    public List<Customer> search(List<Customer> list, String phone) {
        List<Customer> c = new ArrayList<>();
        if (list.isEmpty()) {
            System.out.println("The list is empty!");
            return null;
        }
        else {
            for (Customer customer : list) {
                if (phone.equals(customer.getPhoneNumber())) {
                    c.add(customer);
                }
            }
        }
        return c;
    }
    
    public boolean remove(List<Customer> list, String phone) {
        if (list.isEmpty()) {
            System.out.println("The list is empty!");
            return false;
        }
        else {
            int count = 0;
            for (int i = list.size() - 1; i >= 0; i--) {
                if (phone.equals(list.get(i).getPhoneNumber())) {
                    list.remove(list.get(i));
                    count++;
                }
            }
            if (count == 0) {
                System.out.println("0 results found!");
                return false;
            }
            else return true;
        }
    }
    
    public void menu() {
        System.out.println("\n******************************");
        System.out.println("CUSTOMER MANAGEMENT");
        System.out.println("1. Add a new Customer");
        System.out.println("2. Show all Customers");
        System.out.println("3. Search Customer");
        System.out.println("4. Remove Customer");
        System.out.println("5. Exit");
        System.out.println("******************************");
        System.out.print("Enter your choice: ");
    }
}
