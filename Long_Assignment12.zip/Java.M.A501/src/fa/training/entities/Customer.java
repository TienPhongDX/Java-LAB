/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 23 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.util.List;

public class Customer {
	private String name, phoneNumber, address;
    private List<Order> list;

    public Customer() {
    }

    public Customer(String name, String phoneNumber, String address, List<Order> list) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.list = list;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<Order> getList() {
        return list;
    }

    public void setList(List<Order> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "Customer{" + "name=" + name + ", phoneNumber=" + phoneNumber + ", address=" + address + ", list=" + list + '}';
    }
}
