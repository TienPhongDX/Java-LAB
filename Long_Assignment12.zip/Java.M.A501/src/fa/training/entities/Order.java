/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 23 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Order {
	SimpleDateFormat sDatefm = new SimpleDateFormat ("dd/MM/yyyy");
    private String number;
    private Date date;

    public Order() {
    }

    public Order(String number, Date date) {
        this.number = number;
        this.date = date;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Order[" + "Number: " + number + ", Date: " + sDatefm.format(date) + ']';
    }
}
