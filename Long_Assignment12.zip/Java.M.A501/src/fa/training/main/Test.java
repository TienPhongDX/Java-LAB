/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 23 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import java.util.ArrayList;
import java.util.List;

import fa.training.entities.Customer;
import fa.training.utils.Manager;
import fa.training.utils.Validator;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Customer> list = new ArrayList<>();
        Manager manager = new Manager();
        int choice;

        while (true) {
            manager.menu();
            choice = Validator.checkInputLimit(1, 5);
            switch (choice) {
                case 1:
                    System.out.println("\n");
                    for (Customer c : manager.createCustomer()) {
                        list.add(c);
                    }
                    break;
                case 2:
                    System.out.println("\n");
                    manager.findAll(list);
                    System.out.println("");
                    manager.display(list);
                    manager.save(list);
                    break;
                case 3:
                    System.out.println("\n");
                    System.out.print("Enter customer's phone number: ");
                    String phone = Validator.checkValidPhoneNumber();
                    if (manager.search(list, phone).isEmpty()) {
                        System.out.println("0 results found!");
                    }
                    else {
                        for (Customer customer : manager.search(list, phone)) {
                            System.out.println(customer);
                        }
                    }
                    break;
                case 4:
                    System.out.println("\n");
                    System.out.print("Enter customer's phone number: ");
                    String p = Validator.checkValidPhoneNumber();
                    boolean result = manager.remove(list, p);
                    if (result == true) System.out.println("Deleted successfully!");
                    break;
                case 5:
                    return;
            }
        }
	}

}
