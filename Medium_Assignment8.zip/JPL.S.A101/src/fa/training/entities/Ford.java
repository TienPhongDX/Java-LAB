/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 18 thg 1, 2021
 * Version: 1.0
 *
 */
package fa.training.entities;

public class Ford extends Car {

	private int year;
	private int manufacturerDiscount;

	public Ford() {

	}

	public Ford(int year, int manufacturerDiscount, int speed, double regularPrice, String color) {
		super(speed, regularPrice, color);
		this.year = year;
		this.manufacturerDiscount = manufacturerDiscount;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getManufacturerDiscount() {
		return manufacturerDiscount;
	}

	public void setManufacturerDiscount(int manufacturerDiscount) {
		this.manufacturerDiscount = manufacturerDiscount;
	}

	@Override
	public double getSalePrice() {
		return (super.getSalePrice() - manufacturerDiscount); // To change body of generated methods, choose Tools |
																// Templates.
	}

}
