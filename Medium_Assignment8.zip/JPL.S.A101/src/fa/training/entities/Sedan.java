/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 18 thg 1, 2021
 * Version: 1.0
 *
 */
package fa.training.entities;

public class Sedan extends Car {

	private int length;

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public Sedan(int length, int speed, double regularPrice, String color) {
		super(speed, regularPrice, color);
		this.length = length;
	}

	@Override
	public double getSalePrice() {
		if (length > 20) {
			return super.getSalePrice() - (0.05 * super.getSalePrice());
		} else {
			return super.getSalePrice() - (0.1 * super.getSalePrice());
		}
	}

}
