/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 18 thg 1, 2021
 * Version: 1.0
 *
 */
package fa.training.main;

import fa.training.entities.Car;
import fa.training.entities.Ford;
import fa.training.entities.Sedan;
import fa.training.entities.Truck;

public class MyOwnAutoShop extends Car {

	public static void main(String[] args) {

		Sedan s1 = new Sedan(100, 80, 440.5, "Red");
		Sedan s2 = new Sedan(150, 120, 1450.0, "Blue");
		Sedan s3 = new Sedan(350, 120, 820.5, "Orange");
		Ford f1 = new Ford(1990, 10, 155, 1550.5, "Red");
		Ford f2 = new Ford(2001, 5, 210, 1250.8, "Black");
		Truck t1 = new Truck(1090, 150, 2910.6, "Black");
		Truck t2 = new Truck(1780, 190, 2450.5, "White");

		System.out.println("My Sedan price: " + s1.getSalePrice());
		System.out.println("My Sedan price: " + s2.getSalePrice());
		System.out.println("My Sedan price: " + s3.getSalePrice());
		System.out.println("My Ford price: " + f1.getSalePrice());
		System.out.println("My Ford price: " + f2.getSalePrice());
		System.out.println("My Truck price: " + t1.getSalePrice());
		System.out.println("My Truck price: " + t2.getSalePrice());
	}
}
