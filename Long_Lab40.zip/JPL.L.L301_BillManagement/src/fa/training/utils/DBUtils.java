/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 5 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtils {
	private static DBUtils instance;
	private Connection conn;

	private DBUtils() {
		Properties prop = new Properties();

		try {
			prop.load(DBUtils.class.getResourceAsStream("/dbConfig.properties"));

			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String userName = prop.getProperty("userName");
			String password = prop.getProperty("password");

			Class.forName(driver);
			conn = DriverManager.getConnection(url, userName, password);

		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public Connection getConnection() {
		return conn;
	}

	public static DBUtils getInstance() throws SQLException {
		if (instance == null || instance.getConnection().isClosed()) {
			instance = new DBUtils();
		}
		return instance;
	}
}
