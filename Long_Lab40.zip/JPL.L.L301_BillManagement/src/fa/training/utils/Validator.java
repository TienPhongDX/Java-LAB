/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 5 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.util.regex.Pattern;

public class Validator {
	public static boolean checkInputBillCode(String billCode) {
		return Pattern.matches("^(B)[0-9]{4}$", billCode);
	}
}
