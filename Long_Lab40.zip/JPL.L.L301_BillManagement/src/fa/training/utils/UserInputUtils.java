/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 5 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.util.Scanner;

public class UserInputUtils {

	public static int checkInputInt(String value) {
		int intValue = 0;
		do {
			try {
				intValue = Integer.parseInt(value);
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Please input int value!");
			}
			break;
		} while (true);
		return intValue;
	}
	
	public static float checkInputFloat(String value) {
		float floatValue = 0;
		do {
			try {
				floatValue = Float.parseFloat(value);
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Please input float value!");
			}
			break;
		} while (true);
		return floatValue;
	}
	
	public static double checkInputDouble(String value) {
		Double doubleValue = 0.0;
		do {
			try {
				doubleValue = Double.parseDouble(value);
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Please input double value!");
			}
			break;
		} while (true);
		return doubleValue;
	}
	
	public static String checkInputBillCode(Scanner in) {
		String billCode;
		
		System.out.println("Enter Bill code: ");
		billCode = in.nextLine();
		
		while (!Validator.checkInputBillCode(billCode)) {
			System.out.println("Invalid bill code, Enter again: (example: B0000)");
			billCode = in.nextLine();
		}
		return billCode;
	}
}
