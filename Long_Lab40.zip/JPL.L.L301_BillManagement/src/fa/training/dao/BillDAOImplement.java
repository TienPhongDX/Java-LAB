/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 5 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fa.training.model.Bill;
import fa.training.utils.DBUtils;
import fa.training.utils.SQLCommand;

public class BillDAOImplement implements BillDAO {

	private Connection conn = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet results = null;

	@Override
	public List<Bill> getAll() throws SQLException {
		// TODO Auto-generated method stub
		List<Bill> bills = new ArrayList<>();
		Bill bill = null;

		try {
			conn = DBUtils.getInstance().getConnection();
			preparedStatement = conn.prepareStatement(SQLCommand.BILL_QUERY_FIND_ALL);
			results = preparedStatement.executeQuery();
			while (results.next()) {
				bill = new Bill();

				bill.setBillCode(results.getString("bill_code").trim());
				bill.setCustomerName(results.getString("customer_name"));
				bill.setCreatedDate(results.getString("created_date"));
				bill.setDiscount(results.getFloat("discount"));
				bill.setTotalPrice(results.getDouble("total_price"));
				bills.add(bill);
			}
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return bills;
	}

	@Override
	public boolean saveBill(Bill bill) throws SQLException {
		// TODO Auto-generated method stub
		boolean check = false;
		
		try {
			conn = DBUtils.getInstance().getConnection();
			preparedStatement = conn.prepareStatement(SQLCommand.BILL_QUERY_ADD);

			preparedStatement.setString(1, bill.getBillCode());
			preparedStatement.setString(2, bill.getCustomerName());
			preparedStatement.setString(3, bill.getCreatedDate());
			preparedStatement.setFloat(4, bill.getDiscount());
			results = preparedStatement.executeQuery();
			while (results.next()) {
				if (results.getInt(1) == 1) {
					check = true;
				}
			}
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return check;
	}

	@Override
	public Bill findBillsByBillCode(String billCode) throws SQLException {
		// TODO Auto-generated method stub
		Bill bill = null;
		
		try {
			conn = DBUtils.getInstance().getConnection();
			preparedStatement = conn.prepareStatement(SQLCommand.BILL_QUERY_FIND_BY_CODE);
			preparedStatement.setString(1, billCode);
			results = preparedStatement.executeQuery();
			
			while (results.next()) {
				bill = new Bill();

				bill.setBillCode(results.getString("bill_code").trim());
				bill.setCustomerName(results.getString("customer_name"));
				bill.setCreatedDate(results.getString("created_date"));
				bill.setDiscount(results.getFloat("discount"));
				//bill.setTotalPrice(results.getDouble("total_price"));				
			}
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
		return bill;
	}

	@Override
	public List<Bill> findBillsByCustomerName(String customerName) throws SQLException {
		// TODO Auto-generated method stub
		List<Bill> bills = new ArrayList<>();
		Bill bill = null;
		
		try {
			conn = DBUtils.getInstance().getConnection();
			preparedStatement = conn.prepareStatement(SQLCommand.BILL_QUERY_FIND_BY_CUSTOMER_NAME);
			preparedStatement.setString(1, customerName);
			results = preparedStatement.executeQuery();
			
			while (results.next()) {
				bill = new Bill();
				
				bill.setBillCode(results.getString("bill_code").trim());
				bill.setCustomerName(results.getString("customer_name"));
				bill.setCreatedDate(results.getString("created_date"));
				bill.setDiscount(results.getInt("discount"));
				bill.setTotalPrice(results.getDouble("total_price"));
				
				bills.add(bill);
			}
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return bills;
	}

}
