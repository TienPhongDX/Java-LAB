/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 5 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fa.training.model.Item;
import fa.training.utils.DBUtils;
import fa.training.utils.SQLCommand;

public class ItemDAOImplement implements ItemDAO {
	private Connection conn = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet results = null;

	@Override
	public boolean addItems(List<Item> items) throws SQLException {
		// TODO Auto-generated method stub
		boolean check = false;
		int results[] = null;

		try {
			conn = DBUtils.getInstance().getConnection();
			conn.setAutoCommit(false);
			preparedStatement = conn.prepareStatement(SQLCommand.ITEM_QUERY_ADD);

			items.stream().forEach((item) -> {
				try {
					preparedStatement.setString(1, item.getProductName());
					preparedStatement.setString(2, item.getBillCode().trim());
					preparedStatement.setInt(3, item.getQuantity());
					preparedStatement.setDouble(4, item.getPrice());

					preparedStatement.addBatch();
				} catch (SQLException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			});
			
			results = preparedStatement.executeBatch();
			conn.commit();
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}

		if (results.length > 0) {
			check = true;
		}
		return check;
	}

	@Override
	public boolean deleteItems(List<Item> items) throws SQLException {
		// TODO Auto-generated method stub
		boolean check = false;
		int results[] = null;
		try {
			conn = DBUtils.getInstance().getConnection();
			conn.setAutoCommit(false);
			preparedStatement = conn.prepareStatement(SQLCommand.ITEM_QUERY_DELETE);
			
			items.stream().forEach((item) -> {
				try {
					preparedStatement.setString(1, item.getBillCode());
					preparedStatement.setString(2, item.getProductName());
					
					preparedStatement.addBatch();
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			});
			results = preparedStatement.executeBatch();
			conn.commit();
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
		if (results.length > 0) {
			check = true;
		}
		return check;
	}

	@Override
	public List<Item> getAllByBillCode(String billCode) throws SQLException {
		// TODO Auto-generated method stub
		List<Item> items = new ArrayList<>();
		Item item = null;
		
		try {
			conn = DBUtils.getInstance().getConnection();
			preparedStatement = conn.prepareStatement(SQLCommand.ITEM_QUERY_FIND_ALL);
			preparedStatement.setString(1, billCode);
			results = preparedStatement.executeQuery();
			
			while (results.next()) {
				item = new Item();
				
				item.setBillCode(results.getString("bill_code"));
				item.setProductName(results.getString("product_name"));
				item.setQuantity(results.getInt("quantity"));
				item.setPrice(results.getDouble("price"));
				
				items.add(item);
			}
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return items;
	}

	@Override
	public boolean checkItemExist(Item item) throws SQLException {
		// TODO Auto-generated method stub
		boolean check = false;
		
		try {
			conn = DBUtils.getInstance().getConnection();
			preparedStatement = conn.prepareStatement(SQLCommand.ITEM_QUERY_FIND_CODE_AND_PRODUCT_NAME);
			preparedStatement.setString(1, item.getBillCode());
			preparedStatement.setString(2, item.getProductName());
			results = preparedStatement.executeQuery();
			if (results.next()) {
				check = true;
			}
		} finally {
			// TODO: handle finally clause
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return check;
	}

}
