/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 15 thg 1, 2021
 * Version: 1.0
 *
 */

package exercise2;

import java.util.Scanner;

public class ArrayContains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char choice;
		do {
			Boolean contain = false;
			
			String[] stringArray = { "FTP", "Fresher", "Acedemy", "2018" };
			Scanner in = new Scanner(System.in);

			System.out.println("Input sValue to compare: ");
			String sValue = in.nextLine();
			for (int i = 0; i < stringArray.length; i++) {
				if (stringArray[i].equals(sValue)) {
					contain = true;
					break;
				}
			}
			if (contain)
				System.out.println("Contained!");
			else
				System.out.println("No Contain!");

			System.out.println("Do you want continue: ");
			choice = in.next().charAt(0);
		} while (choice == 'Y' || choice == 'y');
		System.out.println("End program !!");
	}
}
