/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 16 thg 1, 2021
 * Version: 1.0
 *
 */

package exercise3;

import java.util.Scanner;

public class FrequentNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int len, value = 0, inNum, i, count = 0;
		char choice = 0;
		String position;
		Scanner in = new Scanner(System.in);

		System.out.println("Input length for Frequent Array: ");
		len = in.nextInt();
		int[] fqNumber = new int[len];

		for (i = 0; i < fqNumber.length; i++) {
			System.out.println("Input number to Frequent Array: ");
			inNum = in.nextInt();
			fqNumber[i] = inNum;
			if (i > fqNumber.length)break;
			System.out.println("Do you want continue: ");
			choice = in.next().charAt(0);
			if (choice == 'N' || choice == 'n') {
				break;
			}
		}
		for (int j = 0; j < fqNumber.length; j++) {
			System.out.print(fqNumber[j] + " ");
		}
		
		///Count number in Array
		System.out.println("Enter number to find in array: ");
		value = in.nextInt();

		for (int j = 0; j < fqNumber.length; j++) {
			if (fqNumber[j] == value) {
				count++;
			}
		}
		System.out.println("Amount of Frequence: " + count);
		
		// Show position of value
		System.out.print("Indexs: ");
		for (int j = 0; j < fqNumber.length; j++) {
			if (fqNumber[j] == value) {
				System.out.print(j + " ");
			}
		}
	}

}
