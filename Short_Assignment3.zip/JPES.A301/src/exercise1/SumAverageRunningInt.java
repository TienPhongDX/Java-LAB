/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 15 thg 1, 2021
 * Version: 1.0
 *
 */

package exercise1;

public class SumAverageRunningInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int lowerbound = 1,
			upperbound = 100,
			sum = 0;
		for(int i = lowerbound; i<=upperbound; i++) {
			sum+=i;
		}
		System.out.println("Average of all "+upperbound+" first numbers: "+(double)(sum/upperbound));
		
	}

}
