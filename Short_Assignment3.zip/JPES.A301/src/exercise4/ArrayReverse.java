/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 16 thg 1, 2021
 * Version: 1.0
 *
 */

package exercise4;

public class ArrayReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] myIntArray = {43,32,53,23,12,34,3,12,43,32};
		int temp;
		
		System.out.print("Original Array: ");
		for (int i = 0;i<myIntArray.length;i++) {
			if (i==myIntArray.length-1) {
				System.out.print(myIntArray[i]);
			} else {
				System.out.print(myIntArray[i]+", ");
			}
		}
		for (int i = 0; i < myIntArray.length/2; i++) {
			temp = myIntArray[myIntArray.length-i-1];
			myIntArray[myIntArray.length-i-1]= myIntArray[i];
			myIntArray[i] = temp;
			}
		
		System.out.print("\nReversed Array: ");
		for (int i = 0;i<myIntArray.length;i++) {
			if (i==myIntArray.length-1) {
				System.out.print(myIntArray[i]);
			} else {
				System.out.print(myIntArray[i]+", ");
			}
		}
		
		}
	

}
