/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import fa.training.utils.Validator;

public class Course {
	private String code, name;
    private double duration;
    private String status, flag;

    public Course() {
    }

    public Course(String code, String name, double duration, String status, String flag) {
        this.code = code;
        this.name = name;
        this.duration = duration;
        this.status = status;
        this.flag = flag;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "Course{" + "code=" + code + ", name=" + name + ", duration=" + duration + ", status=" + status + ", flag=" + flag + '}';
    }
    
    public Course input() {
        System.out.print("Enter course code (Format: 'FW000'): "); String c = Validator.checkCourseCode();
        System.out.print("Enter course name: "); String n = Validator.checkInputString();
        System.out.print("Enter duration: "); double d = Validator.checkInputDouble();
        System.out.print("Enter status (active / in-active): "); String s = Validator.checkStatus();
        System.out.print("Enter flag (optional / mandatory / n/a): "); String f = Validator.checkFlag();
        
        System.out.println("New couse added!\n");
        Course course = new Course(c, n, d, s, f);
        return course;
    }
}
