/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.util.Scanner;

public class Validator {
public final static Scanner in = new Scanner(System.in);
    
    public static int checkInputInt() {
        while (true) {
            try {
                int result = Integer.parseInt(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be integer! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static double checkInputDouble() {
        while (true) {
            try {
                double result = Double.parseDouble(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be double! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static String checkInputString() {
        while(true){
            String result = in.nextLine().trim();
            if (result.isEmpty()){
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static int checkInputLimit(int min, int max){
        while(true){
            int result = Integer.parseInt(in.nextLine().trim());
            if (result >= min && result <= max) return result;
            else{
                System.err.println("Please input number from "+min+" to "+max+"!");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static boolean checkInputYN() {
        while (true) {
            String result = Validator.checkInputString();
            if (result.equalsIgnoreCase("Y")) return true;
            else if (result.equalsIgnoreCase("N")) return false;
        System.err.println("Please input y/Y or n/N.");
        System.out.print("Enter again: ");
        }
    }
    
    public static String checkCourseCode() {
        while (true) {
            String result = Validator.checkInputString().toUpperCase();
            if (result.length() != 5) {
                System.err.println("Course code is a string of 5 characters, started by �FW� and followed by 3 digits.");
                System.out.print("Enter again: ");
            }
            else if (!result.substring(0, 2).equals("FW") || !result.substring(2).matches("\\d+")) {
                System.err.println("Course code is a string of 5 characters, started by �FW� and followed by 3 digits.");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkStatus() {
        while (true) {
            String result = Validator.checkInputString().toUpperCase();
            if (!result.equalsIgnoreCase("active") && !result.equalsIgnoreCase("in-active")) {
                System.err.println("Status only accepts 'ACTIVE' or 'IN-ACTIVE'.");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkFlag() {
        while (true) {
            String result = Validator.checkInputString().toUpperCase();
            if (!result.equalsIgnoreCase("optional") && !result.equalsIgnoreCase("mandatory") && !result.equalsIgnoreCase("n/a")) {
                System.err.println("Flag only accepts 'OPTIONAL' or 'MANDATORY' or 'N/A'.");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkAttribute() {
        while (true) {
            String result = Validator.checkInputString().toUpperCase();
            if (!result.equalsIgnoreCase("code") && !result.equalsIgnoreCase("name") && !result.equalsIgnoreCase("duration") && !result.equalsIgnoreCase("status") && !result.equalsIgnoreCase("flag")) {
                System.err.println("Please input 'CODE' or 'NAME' or 'DURATION' or 'STATUS' or 'FLAG'.");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
}
