/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import fa.training.entities.Course;
import fa.training.utils.Validator;

public class CourseManagement {

	static final Course[] course = new Course[10];

	public static void main(String[] args) {
		// TODO code application logic here
		Course c = new Course();

		for (int i = 0; i < 10; i++) {
			System.out.println("Course " + (i + 1));
			course[i] = c.input();
		}
		/*
		 * course[0] = new Course("FW001", "Course A", 10, "ACTIVE", "MANDATORY");
		 * course[1] = new Course("FW002", "Course B", 20, "ACTIVE", "OPTIONAL");
		 * course[2] = new Course("FW003", "Course C", 30, "IN-ACTIVE", "N/A");
		 * course[3] = new Course("FW004", "Course D", 40, "IN-ACTIVE", "MANDATORY");
		 * course[4] = new Course("FW005", "Course E", 50, "ACTIVE", "OPTIONAL");
		 * course[5] = new Course("FW006", "Course A", 40, "ACTIVE", "N/A"); course[6] =
		 * new Course("FW007", "Course B", 30, "IN-ACTIVE", "MANDATORY"); course[7] =
		 * new Course("FW008", "Course C", 20, "IN-ACTIVE", "OPTIONAL"); course[8] = new
		 * Course("FW009", "Course D", 10, "ACTIVE", "N/A"); course[9] = new
		 * Course("FW010", "Course F", 50, "ACTIVE", "MANDATORY");
		 */

		for (Course course1 : course) {
			System.out.println(course1);
		}

		System.out.println("\n\n");

		System.out.print("Enter attribute you need to search (code / name / duration / status / flag): ");
		String att = Validator.checkAttribute();
		System.out.print("Enter data: ");
		Object data = Validator.checkInputString().toUpperCase();

		Course[] result = find(att, data);
		int count = 0;

		for (Course c2 : result) {
			if (c2 != null) {
				System.out.println(c2);
				count++;
			}
		}
		if (count == 0)
			System.out.println("There are no results found!");

		System.out.println("\n\n");

		System.out.println("All courses that flag is \"Mandatory\":");
		count = 0;
		for (Course course1 : find("FLAG", "MANDATORY")) {
			if (course1 != null) {
				System.out.println(course1);
				count++;
			}
		}
		if (count == 0)
			System.out.println("There are no results found!");
	}

	public static Course[] find(String type, Object data) {
		Course[] find = new Course[10];
		int pos = 0;
		switch (type) {
		case "CODE":
			for (Course c : course) {
				if (data.equals(c.getCode().toUpperCase())) {
					find[pos] = c;
					pos++;
				}
			}
			break;
		case "NAME":
			for (Course c : course) {
				if (data.equals(c.getName().toUpperCase())) {
					find[pos] = c;
					pos++;
				}
			}
			break;
		case "DURATION":
			for (Course c : course) {
				String du = data.toString();
				if (Double.compare(c.getDuration(), Double.parseDouble(du)) == 0) {
					find[pos] = c;
					pos++;
				}
			}
			break;
		case "STATUS":
			for (Course c : course) {
				if (data.equals(c.getStatus().toUpperCase())) {
					find[pos] = c;
					pos++;
				}
			}
			break;
		case "FLAG":
			for (Course c : course) {
				if (data.equals(c.getFlag().toUpperCase())) {
					find[pos] = c;
					pos++;
				}
			}
			break;
		default:
			System.out.println("END!!!");
			return null;
		}
		return find;
	}
}
