/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package exercise.javaio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JavaIOSample {
	private static final String FILE_PATH = "data.txt";

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		try 
		(BufferedWriter bfWriter = new BufferedWriter(new FileWriter(FILE_PATH, true))) 
		{
			char loop;
			do {
				System.out.print("Enter a string: ");
				String data = in.nextLine();

				bfWriter.write(data + "\n");

				System.out.print("Do you want continue? ");
				loop = in.nextLine().charAt(0);
			} while ((loop == 'y') || (loop == 'Y'));

			bfWriter.flush();
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		List<String> list = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		String strLine = "";
		
		try 
			(BufferedReader bfReader = new BufferedReader(new FileReader(FILE_PATH)))
		{
			
			while ((strLine = bfReader.readLine())!= null) {
				sb.append(strLine);
				sb.append(System.lineSeparator());
				list.add(strLine);
				
			}
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		System.out.println("---*File Content*---");
		for (String data : list) {
			System.out.println(data);
		}
	}
}
