/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.model;

public class Fruit implements Comparable<Fruit>{
	private String fruitName;
	private String fruitDesc;
	private int quantity;
	
	public Fruit() {
		// TODO Auto-generated constructor stub
	}

	public Fruit(String fruitName, String fruitDesc, int quantity) {
		super();
		this.fruitName = fruitName;
		this.fruitDesc = fruitDesc;
		this.quantity = quantity;
	}

	public String getFruitName() {
		return fruitName;
	}

	public void setFruitName(String fruitName) {
		this.fruitName = fruitName;
	}

	public String getFruitDesc() {
		return fruitDesc;
	}

	public void setFruitDesc(String fruitDesc) {
		this.fruitDesc = fruitDesc;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Fruit [fruitName=" + fruitName + ", fruitDesc=" + fruitDesc + ", quantity=" + quantity + "]";
	}

	@Override
	public int compareTo(Fruit compareFruit) {
		// TODO Auto-generated method stub
		int compareQuantity = ((Fruit) compareFruit).getQuantity();
		//ASC order
		return this.quantity - compareQuantity;
		//DESC order
		//*return compareQuantity - this.quantity;
	}
	
	
}
