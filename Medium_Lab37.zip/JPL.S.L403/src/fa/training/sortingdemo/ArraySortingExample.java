/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.sortingdemo;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class ArraySortingExample {
	public void sortArray() {
		// TODO Auto-generated method stub
		System.out.println("sortArray() !!!");
		String[] fruits = new String[] {"Pineapple", "Apple", "Orange", "Banana"};
		Arrays.sort(fruits);
		
		int i = 0;
		for (String temp : fruits) {
			System.out.format("Fruit %d: %s\n", ++i, temp);
		}
	}
}
