/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.sortingdemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListSortingExample {
	
	public void sortArrayList() {
		// TODO Auto-generated method stub
		System.out.println("sortArrayList() !!!");
		List<String> fruits = new ArrayList<>();
		fruits.add("Pineapple");
		fruits.add("Banana");
		fruits.add("Dragon Fruit");
		fruits.add("Orange");
		Collections.sort(fruits);
		int i = 0;
		for (String temp : fruits) {
			System.out.format("Fruit %d: %s\n", ++i, temp);
		}
	}
}
