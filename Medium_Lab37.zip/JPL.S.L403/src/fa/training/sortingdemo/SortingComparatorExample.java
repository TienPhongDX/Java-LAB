/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.sortingdemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import fa.training.model.Fruit;

public class SortingComparatorExample {
	public void sortElementComparator() {
		// TODO Auto-generated method stub
		System.out.println("sortElementComparator() !!!");
		
		List<Fruit> fruitList = new ArrayList<>();
		
		Fruit pineapple = new Fruit("Pineapple", "Pineapple Description", 70);
		Fruit apple = new Fruit("Apple", "Apple Description", 100);
		Fruit orange = new Fruit("Orange", "Orange Description", 80);
		Fruit banana = new Fruit("Banana", "Banana description", 90);

		fruitList.add(pineapple);
		fruitList.add(apple);
		fruitList.add(orange);
		fruitList.add(banana);
		
		System.out.println("Fruits: "+fruitList);
		
		Comparator<Fruit> fruitNameComparator = new Comparator<Fruit>() {
			@Override
			public int compare(Fruit obj1, Fruit obj2) {
				String fruitName1 = obj1.getFruitName().toUpperCase();
				String fruitName2 = obj2.getFruitName().toUpperCase();
			
				// ascending order
				return fruitName1.compareTo(fruitName2);
			}
		};
		
		Collections.sort(fruitList, fruitNameComparator);
		System.out.println("Fruits (Sorted by fruit name): "+fruitList);
		Comparator<Fruit> fruitQuantityComparator = new Comparator<Fruit>() {
		
			@Override
			public int compare(Fruit obj1, Fruit obj2) {
				// TODO Auto-generated method stub
				int fruitQuantity1 = (int) obj1.getQuantity();
				int fruitQuantity2 = (int) obj2.getQuantity();
				if (fruitQuantity1 > fruitQuantity2) {
					return 1;
				} else if (fruitQuantity1 < fruitQuantity2){
					return -1;
				} else {
					return 0;
				}
				
			}
		};
		Collections.sort(fruitList, fruitQuantityComparator);
		System.out.println("Fruits (Sorted by quantity): "+fruitList);
	}
}
