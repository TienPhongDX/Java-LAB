/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import fa.training.dao.customerDAO;
import fa.training.dao.lineItemDAO;
import fa.training.dao.orderDAO;
import fa.training.entities.Customer;
import fa.training.entities.Order;
import fa.training.entities.lineItem;

public class saleManagement {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		customerDAO customer = new customerDAO();
		orderDAO order = new orderDAO();
		lineItemDAO lineItem = new lineItemDAO();
		
		List<Customer> customers = customer.getAllCustomer();
		for (Customer cus : customers) {
			System.out.println(cus);
		}
		
		System.out.println("");
		
		List<Order> orders = order.getAllOrdersByCustomerId(1);
		for (Order ord : orders) {
			System.out.println(ord);
		}
		
		System.out.println("");
		
		List<lineItem> lineItems = lineItem.getAllItemsByOrderId(1);
		for (lineItem lItem : lineItems) {
			System.out.println(lItem);
		}
		
		System.out.println("");
		
		int orderId = 3;
        double total = lineItem.computeOrderTotal(orderId);
        if (total == -1) System.out.println("Order " + orderId + " is not available!");
        else System.out.println("Total price for order " + orderId + " is: " + total);
        
        System.out.println("");
        
        Customer c = new Customer(0, "Ho�ng");
        boolean addCustomer = customer.addCustomer(c);
        System.out.println("Added Customer!");
        
        System.out.println("");
        
        customer.deleteCustomer(7);
        System.out.println("Deleted Customer!");
        
        System.out.println("");
        
        Customer c2 = new Customer(6, "H�ng");
        boolean updateCustomer = customer.updateCustomer(c2);
        System.out.println("Updated Customer!");
        
        System.out.println("");
        
        LocalDate localDate = LocalDate.now();
        Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        Order o = new Order(0, date, 1, 1, 0);
        System.out.println("Added Order!");
        
        System.out.println("");
        
        order.updateOrderTotal(5, 10000.5);
        System.out.println("Updated order!");
	}

}
