/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.common;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseHelper {
	public static Connection getConnection() throws Exception{
		String databaseUrl ="jdbc:sqlserver://Localhost:1433;" +
                "databaseName=SMS; User=sa; Password=Su!nthuyphat";
    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    java.sql.Connection conn= DriverManager.getConnection(databaseUrl);
    return conn;
		
	}
}
