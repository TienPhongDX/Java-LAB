/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public class Product {
	private int productId;
    private String productString;
    private double listPrice;
    
    public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productString, double listPrice) {
		super();
		this.productId = productId;
		this.productString = productString;
		this.listPrice = listPrice;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductString() {
		return productString;
	}

	public void setProductString(String productString) {
		this.productString = productString;
	}

	public double getListPrice() {
		return listPrice;
	}

	public void setListPrice(double listPrice) {
		this.listPrice = listPrice;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productString=" + productString + ", listPrice=" + listPrice
				+ "]";
	}
    
    
}
