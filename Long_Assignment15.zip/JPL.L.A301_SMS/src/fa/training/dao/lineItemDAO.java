/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import fa.training.common.DatabaseHelper;
import fa.training.entities.lineItem;

public class lineItemDAO {
	public List<lineItem> getAllItemsByOrderId(int orderId) throws Exception {
		List<lineItem> list = new ArrayList<>();
		String sql = "select * from LineItem where order_id = ?";
		try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setInt(1, orderId);
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					lineItem item = new lineItem();
					item.setOrderId(rs.getInt(1));
					item.setProductId(rs.getInt(2));
					item.setQuantity(rs.getInt(3));
					item.setPrice(rs.getDouble(4));
					list.add(item);
				}
			}
		}
		return list;
	}

	public Double computeOrderTotal(int orderId) throws Exception {
		String sql = "{?=call computeOrderTotal(?)}";
		double total = 0;
		try (Connection conn = DatabaseHelper.getConnection(); CallableStatement cstmt = conn.prepareCall(sql);) {
			cstmt.registerOutParameter(1, java.sql.Types.INTEGER);
			cstmt.setInt(2, orderId);
			cstmt.execute();
			total = cstmt.getDouble(1);
		}
		return total;
	}

	public boolean addLineItem(lineItem item) throws Exception {
		String sql = "insert into LineItem(order_id, product_id, quantity, price) values(?, ?, ?, ?)";
		try (Connection conn = DatabaseHelper.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setInt(1, item.getOrderId());
			pstmt.setInt(2, item.getProductId());
			pstmt.setInt(3, item.getQuantity());
			pstmt.setDouble(4, item.getPrice());
			return pstmt.executeUpdate() > 0;
		}
	}
}
