/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import fa.training.common.DatabaseHelper;
import fa.training.entities.Order;

public class orderDAO {
	
	public List<Order> getAllOrdersByCustomerId(int customerId) throws Exception {
        List<Order> list = new ArrayList<>();
        String sql = "select * from Orders where customer_id = ?";
        try (
            Connection conn = DatabaseHelper.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, customerId);
            try (ResultSet rs = pstmt.executeQuery();) {
                while (rs.next()) {
                    Order order = new Order();
                    order.setOrderId(rs.getInt(1));
                    order.setOrderDate(rs.getDate(2));
                    order.setCustomerId(rs.getInt(3));
                    order.setEmployeeId(rs.getInt(4));
                    order.setTotal(rs.getDouble(5));
                    list.add(order);
                }
            }
        }
        return list;
    }
	
	public boolean addOrder(Order order) throws Exception {
        String sql = "insert into Orders(order_date, customer_id, employee_id, total) values(?, ?, ?, ?)";
        try (
                Connection conn = DatabaseHelper.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql);) {
            java.sql.Date order_date = new java.sql.Date(order.getOrderDate().getTime());
            pstmt.setDate(1, order_date);
            pstmt.setInt(2, order.getCustomerId());
            pstmt.setInt(3, order.getEmployeeId());
            pstmt.setDouble(4, order.getTotal());
            return pstmt.executeUpdate() > 0;
        }
    }
	
	public boolean updateOrderTotal(int orderId, double orderTotal) throws Exception {
        String sql = "update Orders set total = ? where order_id = ?";
        try (
                Connection conn = DatabaseHelper.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setDouble(1, orderTotal);
            pstmt.setInt(2, orderId);
            return pstmt.executeUpdate() > 0;
        }
    }
}
