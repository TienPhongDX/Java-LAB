/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.dao;

import java.sql.Statement;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import fa.training.common.DatabaseHelper;
import fa.training.entities.Customer;

public class customerDAO {
	public List<Customer> getAllCustomer() throws Exception {
        List<Customer> list = new ArrayList<>();
        String sql = "select * from Customer";
        try (
                Connection conn = DatabaseHelper.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);) {
            while (rs.next()) {
                int id = rs.getInt(1);
                String name = rs.getString(2);
                list.add(new Customer(id, name));
            }
            return list;
        }
    }
	
	public boolean addCustomer(Customer customer) throws Exception {
        String sql = "{call insertCustomer(?)}";
        try (
            Connection conn = DatabaseHelper.getConnection();
            CallableStatement cstmt = conn.prepareCall(sql);) {
            cstmt.setString(1, customer.getCustomerName());
            return cstmt.execute();
        }
    }
	
	public boolean deleteCustomer(int customerId) throws Exception {
        String sql = "{call deleteCustomer(?)}";
        try (
            Connection conn = DatabaseHelper.getConnection();
            CallableStatement cstmt = conn.prepareCall(sql);) {
            cstmt.setInt(1, customerId);
            return cstmt.execute();
        }
    }
	
	public boolean updateCustomer(Customer customer) throws Exception {
        String sql = "{call updateCustomer(?,?)}";
        try (
            Connection conn = DatabaseHelper.getConnection();
            CallableStatement cstmt = conn.prepareCall(sql);) {
            cstmt.setInt(1, customer.getCustomerId());
            cstmt.setString(2, customer.getCustomerName());
            return cstmt.execute();
        }
    }
}
