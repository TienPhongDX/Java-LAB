/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashmapdemo;

import java.util.HashMap;
import java.util.Map;

import fa.training.model.Employee;

public class HashMapCreationExample {
	public void createHashMap() {
		// TODO Auto-generated method stub
		System.out.println("createHashMap() !!!");
		Map<String, Integer> numberMapping = new HashMap<>();

		numberMapping.put("One", 1);
		numberMapping.put("Two", 2);
		numberMapping.put("Three", 3);
		
		numberMapping.putIfAbsent("Four", 4);
		System.out.println(numberMapping);
		
	}
	
	public void createEmployeeMap() {
		System.out.println("createEmployeeMap() !!!");
		Map<Integer, Employee> empMap = new HashMap<>();
		
		empMap.put(1001, new Employee(1001, "Phong", "La Hai"));
		empMap.put(1002, new Employee(1002, "Thuy", "Da Nang"));
		empMap.put(1003, new Employee(1003, "Thoi", "Sai Gon"));
		System.out.println(empMap);
	}
}
