/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashmapdemo;

import java.util.HashMap;
import java.util.Map;

public class HashMapAccessKeyExample {
	public void accessKeys() {
		// TODO Auto-generated method stub
		System.out.println("accessKeys() !!!");
		Map<String, String> userCityMapping = new HashMap<>();

		System.out.println("is userCityMapping empty? : " + userCityMapping.isEmpty());

		userCityMapping.put("John", "NYC");
		userCityMapping.put("Raven", "VietNam");
		userCityMapping.put("Phong", "HCM");
		System.out.println("userCityMapping HashMap: " + userCityMapping);
		System.out.format("We have the city info of %d users\n", userCityMapping.size());
		String username = "John";
		if (userCityMapping.containsKey(username)) {
			String city = userCityMapping.get(username);
			System.out.println(username + " lives in " + city);

		} else {
			System.out.println("City details not found for user" + username);

		}
		
		if (userCityMapping.containsValue("NYC")) {
			System.out.println("There is a user in the userCityMapping who lives in NYC");
		} else {
			System.out.println("There is no user in the userCityMapping who lives in NYC");
		}
		
		userCityMapping.put(username, "California");
		System.out.println(username+" moved to a new city"+userCityMapping.get(username)+", New userCityMapping: "+userCityMapping);
		System.out.println("Raven's city: "+userCityMapping.get("Raven"));
	}
}
