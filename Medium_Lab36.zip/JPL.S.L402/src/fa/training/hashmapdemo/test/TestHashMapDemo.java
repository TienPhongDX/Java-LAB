/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashmapdemo.test;

import fa.training.hashmapdemo.HashMapAccessKeyExample;
import fa.training.hashmapdemo.HashMapCreationExample;
import fa.training.hashmapdemo.HashMapIteratorExample;
import fa.training.hashmapdemo.HashMapObtainKeySetExample;
import fa.training.hashmapdemo.HashMapRemoveKeyExample;

public class TestHashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapCreationExample hashMapCreation = new HashMapCreationExample();
		HashMapAccessKeyExample hashMapAccess = new HashMapAccessKeyExample();
		HashMapObtainKeySetExample hashMapKeySet = new 
								HashMapObtainKeySetExample();
		HashMapIteratorExample hashMapIterator = new HashMapIteratorExample();
		HashMapRemoveKeyExample hashMapRemove = new HashMapRemoveKeyExample();
		hashMapCreation.createHashMap();
		hashMapCreation.createEmployeeMap();
		hashMapAccess.accessKeys();
		hashMapKeySet.obtainEntryKeySetValues();
		hashMapIterator.iterateHashMap();
		hashMapRemove.removeKeys();
	}

}
