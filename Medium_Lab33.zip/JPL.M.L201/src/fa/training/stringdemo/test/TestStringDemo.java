/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.stringdemo.test;

import fa.training.stringdemo.StringCountNumberOfWord;
import fa.training.stringdemo.StringImmutableExample;
import fa.training.stringdemo.StringMethodExample;

public class TestStringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringImmutableExample stringImmutable = new StringImmutableExample();
		StringMethodExample stringMethod = new StringMethodExample();
		StringCountNumberOfWord countWord = new StringCountNumberOfWord();
		stringImmutable.demonstrateStringImmutable();
		stringMethod.demonstrateStringMethod();
		countWord.demonstrateCountWord();
	}

}
