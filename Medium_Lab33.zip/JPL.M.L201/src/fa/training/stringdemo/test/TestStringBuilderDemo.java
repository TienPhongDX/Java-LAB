/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 27 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.stringdemo.test;

import fa.training.stringbufferdemo.StringBufferExample;
import fa.training.stringbuilderdemo.StringBuilderExample;

public class TestStringBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilderExample stringBuilder = new StringBuilderExample();
		StringBufferExample stringBuffer = new StringBufferExample();
		stringBuilder.demonstrateStringBuilder();
		stringBuffer.demonstrateStringBuffer();
	}

}
