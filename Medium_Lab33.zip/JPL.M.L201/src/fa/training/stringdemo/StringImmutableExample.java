/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.stringdemo;

public class StringImmutableExample {
	public void demonstrateStringImmutable() {
		System.out.println("demonstrateStringImmuatble() !!!");
		String s1 = "Java";
		String s2 = s1;
		System.out.println(s1 == s2);
		s1 = "Python";
		System.out.println(s1 == s2);
		System.out.println(s2);
	}
}
