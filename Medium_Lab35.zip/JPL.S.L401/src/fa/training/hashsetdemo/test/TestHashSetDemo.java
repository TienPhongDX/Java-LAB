/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashsetdemo.test;

import fa.training.hashsetdemo.HashSetCreationExample;
import fa.training.hashsetdemo.HashSetIterationExample;
import fa.training.hashsetdemo.HashSetRemoveElementExample;
import fa.training.hashsetdemo.HashSetRetrieveElementExample;

public class TestHashSetDemo {
	public static void main(String[] args) {
		HashSetCreationExample hashSetCreation = new HashSetCreationExample();
		HashSetRetrieveElementExample hashSetElements = 
						new HashSetRetrieveElementExample();
		HashSetRemoveElementExample hashSetRemove = 
						new HashSetRemoveElementExample();
		HashSetIterationExample hashSetIterator = new HashSetIterationExample();
		
		System.out.println("-------------------------------------------------");
		hashSetCreation.createHashSet();
		System.out.println("-------------------------------------------------");
		hashSetElements.retrieveElements();
		System.out.println("-------------------------------------------------");
		hashSetRemove.removeElement();
		System.out.println("-------------------------------------------------");
		hashSetIterator.hashSetIterator();
		System.out.println("\n-------------------------------------------------");
		
	}
}
