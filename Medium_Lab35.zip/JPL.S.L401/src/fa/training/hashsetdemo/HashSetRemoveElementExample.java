/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashsetdemo;

import java.util.HashSet;
import java.util.Set;

public class HashSetRemoveElementExample {

	public void removeElement() {
		// TODO Auto-generated method stub
		System.out.println("removeElement() !!!");
		Set<String> hashSet = new HashSet<>();

		hashSet.add("Wilson");
		hashSet.add("Google");
		hashSet.add("Sony");
		hashSet.add("Vinfast");
		hashSet.add("Nike");

		Set<String> hashSet2 = new HashSet<>();

		hashSet2.add("Wilson");
		hashSet2.add("Apple");
		hashSet2.add("Sony");

		System.out.println(hashSet);

		hashSet.remove("Nike");
		hashSet.remove("Google");

		System.out.println(hashSet);

		hashSet.removeAll(hashSet2);
		System.out.println(hashSet);
		if (hashSet.isEmpty())
			System.out.println("The brands set is empty");

	}
}
