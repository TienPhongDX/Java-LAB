/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashsetdemo;

import java.util.HashSet;
import java.util.Set;

public class HashSetRetrieveElementExample {
	public void retrieveElements() {
		// TODO Auto-generated method stub
		System.out.println("retrieveElements() !!!");
		Set<String> hashSet = new HashSet<>();

		hashSet.add("Wilson");
		hashSet.add("Google");
		hashSet.add("Sony");
		hashSet.add("Vinfast");
		hashSet.add("Nike");

		if (hashSet.contains("Vinfast")) {
			System.out.println("The set contains the Vinfast element");
		} else
			System.out.println("The set not contains the Vinfast element");

		if (hashSet.contains("Samsung")) {
			System.out.println("The set contains the Samsung element");
		} else
			System.out.println("The set not contains the Samsung element");

		hashSet.clear();
		if (hashSet.isEmpty())
			System.out.println("The set does not contain any elements.");
	}
}
