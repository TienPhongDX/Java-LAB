/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashsetdemo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetIterationExample {
	public void hashSetIterator() {
		// TODO Auto-generated method stub
		System.out.println("hashSetIterator() !!!");
		Set<String> hashSet = new HashSet<>();

		hashSet.add("Wilson");
		hashSet.add("Google");
		hashSet.add("Sony");
		hashSet.add("Vinfast");
		hashSet.add("Nike");

		Iterator<String> it = hashSet.iterator();
		while (it.hasNext()) {
			String element = it.next();
			System.out.print(element+"\t");
		}
	}
}
