/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.hashsetdemo;

import java.util.HashSet;
import java.util.Set;

public class HashSetCreationExample {
	public void createHashSet() {
		System.out.println("CreateHashSet() !!!");
		Set<String> hashSet = new HashSet<>();

		hashSet.add("Wilson");
		hashSet.add("Google");
		hashSet.add("Sony");
		hashSet.add("Vinfast");
		hashSet.add("Nike");

		int noOfElement = hashSet.size();
		System.out.format("The set contain %d  elements \n", noOfElement);
		System.out.println(hashSet);
	}
}
