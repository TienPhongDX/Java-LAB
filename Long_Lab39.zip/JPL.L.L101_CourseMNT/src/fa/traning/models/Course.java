/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.traning.models;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import fa.training.utils.InvalidIdException;
import fa.training.utils.Validator;

public class Course implements Serializable, Statistical {

	private static final long serialVersionUID = 1L;
	private String ID;
	private String title;
	private Set<Student> students;
	private double credit;
	private int enrollment;

	public Course() {
		// TODO Auto-generated constructor stub
	}

	public Course(String iD, String title, Set<Student> students, double credit, int enrollment) {
		super();
		this.ID = iD;
		this.title = title;
		this.students = students;
		this.credit = credit;
		this.enrollment = enrollment;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) throws InvalidIdException {
		if ((Validator.checkInputCourseID(iD)) && (Validator.checkIDExisted(iD))) {
			this.ID = iD;
		} else {
			throw new InvalidIdException("ID is invalid");
		}
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	public double getCredit() {
		return credit;
	}

	public void setCredit(double credit) {
		this.credit = credit;
	}

	public int getEnrollment() {
		return enrollment;
	}

	public void setEnrollment(int enrollment) {
		this.enrollment = enrollment;
	}

	@Override
	public Map<String, Integer> getStatistic() {
		// TODO Auto-generated method stub
		Map<String, Integer> stats = new HashMap<String, Integer>();  
		 stats.put("A", 0);  
		 stats.put("B", 0);  
		 stats.put("C", 0);  
		 stats.put("D", 0);  
		 for (Student student : students) {  
		     if (student.getGPA() >= 8.5) {  
		         stats.put("A", stats.get("A") + 1);  
		     } else if (student.getGPA() < 8.5 && student.getGPA() >= 7) {  
		         stats.put("B", stats.get("B") + 1);  
		     } else if (student.getGPA() < 7 && student.getGPA() >= 6) {  
		         stats.put("C", stats.get("C") + 1);  
		     } else {  
		         stats.put("D", stats.get("D") + 1);  
		     }  
		 }  
		 return stats; 
	}
}
