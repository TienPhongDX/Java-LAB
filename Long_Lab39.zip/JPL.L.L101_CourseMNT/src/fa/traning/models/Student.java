/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.traning.models;

import fa.training.utils.InvalidIdException;
import fa.training.utils.PhoneFormatException;
import fa.training.utils.Validator;

public class Student {
	public static final long serialVersionUID = 1L;
	private String ID;
	private String Name;
	private String Phone;
	private String Gender;
	private double GPA;

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(String iD, String name, String phone, String gender, double gPA) {
		super();
		this.ID = iD;
		this.Name = name;
		this.Phone = phone;
		this.Gender = gender;
		this.GPA = gPA;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) throws InvalidIdException {
		if (Validator.checkInputStudentID(iD)) {
			this.ID = iD;
		} else {
			throw new InvalidIdException("ID � invalid!");
		}
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) throws PhoneFormatException {
		if (Validator.checkInputPhone(phone)) {
			this.Phone = phone;
		} else {
			throw new PhoneFormatException("Phone number is invalid!");
		}
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		this.Gender = gender;
	}

	public double getGPA() {
		return GPA;
	}

	public void setGPA(double gPA) {
		this.GPA = gPA;
	}

	@Override
	public String toString() {
		return "Student [ID=" + this.ID + ", Name=" + this.Name + ", Phone=" + this.Phone + ", Gender=" + this.Gender
				+ ", GPA=" + this.GPA + "]";
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.ID == null) ? 0 : this.ID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (ID == null) {
			if (other.ID != null)
				return false;
		} else if (!ID.equals(other.ID))
			return false;
		return true;
	}
}
