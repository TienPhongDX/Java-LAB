/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.traning.models;

import java.util.Map;

public interface Statistical {
	public Map<String, Integer> getStatistic();
}
