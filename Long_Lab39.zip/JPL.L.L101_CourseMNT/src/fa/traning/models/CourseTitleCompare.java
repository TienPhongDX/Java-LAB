/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.traning.models;

import java.util.Comparator;

public class CourseTitleCompare implements Comparator<Course>{

	@Override
	public int compare(Course o1, Course o2) {
		// TODO Auto-generated method stub
		return o1.getID().compareToIgnoreCase(o2.getID());
	}

}
