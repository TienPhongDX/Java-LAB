/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 4 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import java.io.IOException;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

import fa.training.services.CourseService;
import fa.training.utils.Constant;
import fa.traning.models.Course;

public class CourseManagement {

	private static List<Course> listNewCourse;
	private static List<Course> listCourse;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String choice, status, studentId, courseId;
		Scanner in = null;
		List<Course> courseByStudent;
		CourseService courseService = new CourseService();
		try {
			in = new Scanner(System.in);
			do {
				System.out.println("---------MENU---------");
				System.out.println("1. Create new Course" + "\n2. Save to file" + "\n3. Sort by ID"
						+ "\n4. Find by Student" + "\n5. Remove course" + "\n6. Course Statistic" + "\n7. Exit");
				System.out.print("Select: ");
				choice = in.nextLine();
				choice = choice.trim();
				switch (choice) {
				case Constant.INPUT:
					if (listNewCourse != null) {
						listNewCourse.clear();
					}
					listNewCourse = courseService.createCourse(in);
					System.out.println("Input done!");
					break;
				case Constant.SAVE:
					try {
						if (listNewCourse == null) {
							throw new Exception();
						}
						status = courseService.save(listNewCourse);
						System.out.println("Save: " + status);
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("Save fail!");
					}
					break;
				case Constant.SORT:
					if (listCourse != null) {
						listCourse.clear();
					}
					try {
						listCourse = courseService.getAll();
						if (listCourse == null) {
							throw new IOException();
						}
						courseService.sortAndDisplay(listCourse);
					} catch (IOException e) {
						// TODO: handle exception
						System.out.println("No data");
					}
					break;
				case Constant.SEARCH:
					try {
						System.out.println("Enter student ID: ");
						studentId = in.nextLine();
						courseByStudent = courseService.getByStudent(studentId);
						if (courseByStudent == null) {
							throw new IOException();
						}
						System.out.println("---List of Students---");
						for (Course course : courseByStudent) {
							System.out.println(course.getID()+"\t"
											  +course.getTitle()+"\t"
											  +course.getCredit()+"\t"
											  +course.getEnrollment());
						}
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("No data");
					}
					break;
				case Constant.REMOVE:
					System.out.println("Enter course ID to remove: ");
					courseId = in.nextLine();
					
					try {
						status = courseService.remove(courseId);
						System.out.println("Remove: "+ status);
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("Remove Fail!");
					}
					break;
				case Constant.STATS:
					if (listCourse != null) {
						listCourse.clear();
					}
					try {
						listCourse = courseService.getAll();
						if (listCourse == null) {
							throw new IOException();
						}
						for (Course course : listCourse) {
							System.out.println("---"+ course.getID()+"---");
							for(Entry<String, Integer> entry : course.getStatistic().entrySet()) {
								System.out.println(entry.getKey()+" | "+entry.getValue());
							}
						}
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("No data");
					}
					break;
				default:
					choice = Constant.EXIT;
					break;
				}
			} while (!choice.equalsIgnoreCase(Constant.EXIT));
		} finally {
			if (in != null) {
				in.close();
			}
		}
	}

}
