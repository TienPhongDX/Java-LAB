/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

public class Constant {
	public static final String FILE_PATH = "course.dat";
	public static final String SUCCESS = "success";
	public static final String FAIL = "fail";
	public static final String INPUT = "1";
	public static final String SAVE = "2";
	public static final String SORT = "3";
	public static final String SEARCH = "4";
	public static final String REMOVE = "5";
	public static final String STATS = "6";
	public static final String EXIT = "7";
}
