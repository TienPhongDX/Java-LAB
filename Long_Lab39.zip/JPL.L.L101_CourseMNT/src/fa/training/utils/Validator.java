/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
	private static final String VALID_PHONE_REGEX = "^\\d{10,}$";
	private static final String VALID_STUDENT_ID_REGEX = "^\\d{6}$";
	private static final String VALID_COURSE_ID_REGEX = "[A-Z]{2}\\d{3}";
	private static Set<String> ids = new HashSet<String>();
	
	public static boolean checkInputPhone(String phone) {
		
		Pattern pattern = Pattern.compile(VALID_PHONE_REGEX);
		Matcher matcher = pattern.matcher(phone);
		return matcher.matches();
	
	}
	
	public static boolean checkInputStudentID(String ID) {
		
		Pattern pattern = Pattern.compile(VALID_STUDENT_ID_REGEX);
		Matcher matcher = pattern.matcher(ID);
		return matcher.matches();
		
	}
	
	public static boolean checkInputCourseID(String ID) {
		
		Pattern pattern = Pattern.compile(VALID_COURSE_ID_REGEX);
		Matcher matcher = pattern.matcher(ID);
		return matcher.matches();
		
	}
	
	public static double checkInputCredit(String credit) {
		double doCredit = 0d;
		try {
			doCredit = Double.parseDouble(credit);
		} catch (NumberFormatException e) {
			// TODO: handle exception
			throw new NumberFormatException();
		}
		return doCredit;
	}
	
	public static int checkInputEnrollment(String enrollment) {
		int intEnrollment = 0;
		try {
			intEnrollment = Integer.parseInt(enrollment);
		} catch (NumberFormatException e) {
			// TODO: handle exception
			throw new NullPointerException();
		}
		return intEnrollment;
	}
	
	
	public static Set<String> getIDs() {
		return ids;
	}
	public static boolean checkIDExisted(String ID) {
		if (!ids.contains(ID)) {
			ids.add(ID);
			return true;
		} else {
			return false;
		}
	}
}
