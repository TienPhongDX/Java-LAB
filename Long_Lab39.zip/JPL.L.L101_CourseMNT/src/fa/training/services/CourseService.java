/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.services;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import fa.training.utils.Constant;
import fa.training.utils.InvalidIdException;
import fa.training.utils.Validator;
import fa.traning.models.Course;
import fa.traning.models.CourseTitleCompare;
import fa.traning.models.Student;

public class CourseService {

	public List<Course> createCourse(Scanner in) {
		String loop, id, title, credit, enrollment;
		double doCredit;
		int intEnrollment;
		Course course;
		Set<Student> students = new HashSet<>();
		List<Course> courses = new ArrayList<>();
		StudentService studentService = new StudentService();

		do {
			course = new Course();

			do {
				System.out.println("Enter Course ID: ");
				id = in.nextLine();
				try {
					course.setID(id);
				} catch (InvalidIdException e) {
					// TODO: handle exception
					continue;
				}
				break;
			} while (true);

			System.out.println("Enter course title: ");
			title = in.nextLine();
			course.setTitle(title);

			do {
				System.out.println("Enter course credit: ");
				credit = in.nextLine();
				try {
					doCredit = Validator.checkInputCredit(credit);
					course.setCredit(doCredit);
				} catch (NumberFormatException e) {
					// TODO: handle exception
					continue;
				}
				break;
			} while (true);

			do {
				System.out.println("Enter course enrollment: ");
				enrollment = in.nextLine();
				try {
					intEnrollment = Validator.checkInputEnrollment(enrollment);
					course.setEnrollment(intEnrollment);
				} catch (NumberFormatException e) {
					// TODO: handle exception
					continue;
				}
				break;
			} while (true);

			System.out.println("---Enter Student in the Course---");
			students = studentService.createStudent(in, intEnrollment);
			course.setStudents(students);

			courses.add(course);

			System.out.println("Do you want continue to input course (Y/N)? : ");
			loop = in.nextLine();

		} while (loop.charAt(0) == 'Y' || loop.charAt(0) == 'y');

		return courses;
	}

	public String save(List<Course> courses) throws Exception {
		ObjectOutputStream objectOutputStream = null;
		try {
			objectOutputStream = new ObjectOutputStream(new FileOutputStream(Constant.FILE_PATH));
			objectOutputStream.writeObject(courses);
		} catch (Exception e) {
			// TODO: handle exception
			throw new Exception();
		} finally {
			if (objectOutputStream != null) {
				objectOutputStream.close();
			}
		}
		return Constant.SUCCESS;
	}
	
	public List<Course> getAll() throws IOException {
		ObjectInputStream objectInputStream = null;
		List<Course> courses;
		try {
			objectInputStream = new ObjectInputStream(new FileInputStream(Constant.FILE_PATH));
			courses = (List<Course>) objectInputStream.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			throw new IOException();
		} finally {
			if (objectInputStream != null) {
				objectInputStream.close();
			}
		}
		return courses;
	}
	
	public void sortAndDisplay(List<Course> courses) {
		Collections.sort(courses, new CourseTitleCompare());
		System.out.println("---------- COURSE LIST ----------");
		for (Course course : courses) {
			System.out.format("%s | %20s | %12.3f | %5d | %100s \n", 
					course.getID(), course.getTitle(), course.getCredit(), 
					course.getEnrollment(), course.getStudents());
		}
	}
	
	public List<Course> getByStudent(String studentId) throws IOException {
		List<Course> courses = getAll();
		List<Course> coursesByStudent = new ArrayList<>();
		
		if (courses != null) {
			for (Course course : courses) {
				for (Student studentCourse : course.getStudents()) {
					if (studentId.equalsIgnoreCase(studentCourse.getID())) {
						coursesByStudent.add(course);
					}
				}
			}
		}
		return coursesByStudent;
	}
	
	public String remove(String id) throws Exception {
		boolean removed = false;
		
		List<Course> courses = getAll();
		if (courses == null) {
			throw new IOException();
		}
		
		Iterator<Course> iterator = courses.iterator();
		while (iterator.hasNext()) {
			Course course = (Course) iterator.next();
			if (id.equalsIgnoreCase(course.getID())) {
				iterator.remove();
				removed = true;
				break;
			}
		}
		
		if (removed) {
			try {
				save(courses);
			} catch (Exception e) {
				// TODO: handle exception
				throw new Exception();
			}
			return Constant.SUCCESS;
		}
		return Constant.FAIL;
	}
}
