/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.services;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import fa.training.utils.InvalidIdException;
import fa.training.utils.PhoneFormatException;
import fa.training.utils.Validator;
import fa.traning.models.Student;

public class StudentService {

	public Set<Student> createStudent(Scanner in, int maxSize) {
		String loop = "";
		String id, name, phone, gender, gpa;
		Student student;
		boolean addStatus = false;

		Set<Student> students = new HashSet<>();
		do {
			student = new Student();

			do {
				System.out.println("Enter student ID: ");
				id = in.nextLine();
				try {
					student.setID(id);
				} catch (InvalidIdException e) {
					// TODO: handle exception
					continue;
				}
				break;
			} while (true);

			System.out.println("Enter student name: ");
			name = in.nextLine();
			student.setName(name);

			System.out.println("Enter student gender: ");
			gender = in.nextLine();
			student.setGender(gender);

			System.out.println("Enter student GPA: ");
			gpa = in.nextLine();
			student.setGPA(Double.parseDouble(gpa));

			do {
				System.out.println("Enter student phone: ");
				phone = in.nextLine();
				try {
					student.setPhone(phone);
				} catch (PhoneFormatException e) {
					// TODO: handle exception
					continue;
				}
				break;
			} while (true);

			addStatus = students.add(student);
			if (!addStatus) {
				System.out.println("<<Student existed in Enroll!>>");
			}

			if (students.size() < maxSize) {
				System.out.println("Do you want continue to input student for this course (Y/N)? : ");
				loop = in.nextLine();
			} else {
				loop = "N";
			}

			if (loop.charAt(0) != 'Y' && loop.charAt(0) != 'y') {
				Validator.getIDs().clear();
			}
		} while (loop.charAt(0) == 'Y' || loop.charAt(0) == 'y');

		return students;

	}
}
