/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package training.arraylist;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PairManagement pm = new PairManagement();
		System.out.println("Before switch: "+pm.getLists());
		pm.SwitchPairs();
		System.out.println("After switch: "+pm.getLists());
	}

}
