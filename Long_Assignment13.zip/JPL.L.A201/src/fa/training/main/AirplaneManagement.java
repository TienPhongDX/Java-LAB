/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import fa.training.utils.Validator;

public class AirplaneManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager manager = new Manager();
		int choice;
		manager.createExAirport();
		while (true) {
			manager.mainMenu();
			choice = Validator.checkInputLimit(1, 14);
			switch (choice) {
			case 1:
				manager.createFixedWing();
				break;
			case 2:
				manager.createHelicopter();
				break;
			case 3:
				manager.addAirport();
				break;
			case 4:
				manager.displayAirport();
				break;
			case 5:
				manager.displayAirportStatus();
				break;
			case 6:
				manager.displayFixedwingAirplane();
				break;
			case 7:
				manager.displayHelicopter();
				break;
			case 8:
				return;
			case 9:
				manager.addFixedWing();
				break;
			case 10:
				manager.removeFixedWing();
				break;
			case 11:
				manager.addHelicopter();
				break;
			case 12:
				manager.removeHelicopter();
				break;
			case 13:
				manager.updateFixedWing();
				break;
			case 14:
				manager.save();
				break;
			}
		}
	}

}
