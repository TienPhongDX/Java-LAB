/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import fa.training.entities.Airport;
import fa.training.entities.Fixedwing;
import fa.training.entities.Helicopter;
import fa.training.utils.Validator;

public class Manager {
	List<Fixedwing> fixedwing = new ArrayList<>();
	List<Helicopter> helicopter = new ArrayList<>();
	List<Airport> airport = new ArrayList<>();

	public void createExAirport() {
		Airport a1 = new Airport("AP00001", "Dong Tac", 16.5, 2, null, 4, null);
		airport.add(a1);
		Airport a2 = new Airport("AP00002", "Noi Bai", 26.4, 5, null, 6, null);
		airport.add(a2);
		Airport a3 = new Airport("AP00003", "Tan Son Nhat", 25, 7, null, 5, null);
		airport.add(a3);
		Airport a4 = new Airport("AP00004", "Cam Ranh", 16.6, 3, null, 3, null);
		airport.add(a4);

		System.out.println(airport.size() + " example airports auto created!!");

	}

	public void createFixedWing() {
		System.out.print("Enter airplane's ID: ");
		String id = Validator.checkValidIDFixedwing();
		while (checkIDFixedWing(id) != -1) {
			System.err.println("ID is already existed!");
			System.out.print("Enter again: ");
			id = Validator.checkValidIDFixedwing();
		}
		System.out.print("Enter airplane's model: ");
		String model = Validator.checkValidModel();
		System.out.print("Enter airplane's cruise speed: ");
		double speed = Validator.checkInputDouble();
		System.out.print("Enter airplane's empty weight: ");
		double emptyWeight = Validator.checkInputPositive();
		System.out.print("Enter airplane's max takeoff weight: ");
		double takeOffWeight = Validator.checkValidFixedWingTakeoffWeight(emptyWeight);
		System.out.print("Enter airplane's type: ");
		String planeType = Validator.checkValidFixedwingType();
		System.out.print("Enter airplane's min needed runway size: ");
		double minRunwaySize = Validator.checkInputPositive();
		Fixedwing f = new Fixedwing(id, model, speed, emptyWeight, takeOffWeight, planeType, minRunwaySize);
		fixedwing.add(f);
		System.out.println("New fixed-wing airplane added!");
	}

	public int checkIDFixedWing(String ID) {
		if (fixedwing.isEmpty()) {
			return -1;
		} else {
			for (int i = 0; i < fixedwing.size(); i++) {
				if (fixedwing.get(i).getId().equals(ID)) {
					return i;
				}
			}
		}
		return -1;
	}

	public void createHelicopter() {
		System.out.print("Enter helicopter's ID: ");
		String id = Validator.checkValidIDHelicopter();
		while (checkIDHelicopter(id) != -1) {
			System.err.println("ID is already existed!");
			System.out.print("Enter again: ");
			id = Validator.checkValidIDHelicopter();
		}
		System.out.print("Enter helicopter's model: ");
		String model = Validator.checkValidModel();
		System.out.print("Enter helicopter's cruise speed: ");
		double speed = Validator.checkInputDouble();
		System.out.print("Enter helicopter's empty weight: ");
		double emptyWeight = Validator.checkInputPositive();
		System.out.print("Enter helicopter's max takeoff weight: ");
		double takeoffWeight = Validator.checkValidHelicopterTakeoffWeight(emptyWeight);
		System.out.print("Enter helicopter's range: ");
		double range = Validator.checkInputPositive();
		Helicopter h = new Helicopter(id, model, speed, emptyWeight, takeoffWeight, range);
		helicopter.add(h);
		System.out.println("New helicopter added!");
	}

	public int checkIDHelicopter(String ID) {
		if (helicopter.isEmpty()) {
			return -1;
		} else {
			for (int i = 0; i < helicopter.size(); i++) {
				if (helicopter.get(i).getId().equals(ID)) {
					return i;
				}
			}
		}
		return -1;
	}

	public void addAirport() {
		System.out.print("Enter airport's ID: ");
		String id = Validator.checkValidIDAirport();
		while (checkIDAirport(id) != -1) {
			System.err.println("ID is already existed!");
			System.out.print("Enter again: ");
			id = Validator.checkValidIDAirport();
		}
		System.out.print("Enter airport's name: ");
		String name = Validator.checkInputString();
		System.out.print("Enter airport's runway size: ");
		double runwaySize = Validator.checkInputPositive();
		System.out.print("Enter airport's max fixed-wing parking place: ");
		int fixedwingPark = Validator.checkInputIntPositive();
		System.out.print("Enter airport's max helicopter parking place: ");
		int helicopterPark = Validator.checkInputIntPositive();
		Airport a = new Airport(id, name, runwaySize, fixedwingPark, null, helicopterPark, null);
		airport.add(a);
		System.out.println("New airport added!");
	}

	public int checkIDAirport(String ID) {
		if (airport.isEmpty()) {
			return -1;
		} else {
			for (int i = 0; i < airport.size(); i++) {
				if (airport.get(i).getId().equals(ID)) {
					return i;
				}
			}
		}
		return -1;
	}

	public void displayAirport() {
		if (airport.isEmpty()) {
			System.out.println("There are no airports created!");
		} else {
			Collections.sort(airport);
			System.out.printf("%-10s%-20s%-15s%-30s%-30s%-30s%-30s", "ID", "Name", "Runway Size",
					"Fixed-wing Parking Capacity", "Fixed-wing's ID List", "Helicopter Parking Capacity",
					"Helicopter's ID List");
			for (Airport a : airport) {
				System.out.println("");
				a.display();
			}
			System.out.println("");
		}
	}

	public void displayAirportStatus() {
		if (airport.isEmpty()) {
			System.out.println("There are no airports created!");
		} else {
			System.out.print("Enter an airport's ID: ");
			String id = Validator.checkValidIDAirport();
			int i = checkIDAirport(id);
			if (i == -1) {
				System.out.println("Airport's ID is not available!");
			} else {
				Airport a = airport.get(i);
				System.out.println("ID: " + a.getId());
				System.out.println("Name: " + a.getName());
				System.out.println("Fixed-wing Airplanes Capacity: " + a.getMaxParkingFixedwing());
				int n1;
				if (a.getIdParkingFixedwing() == null || a.getIdParkingFixedwing().isEmpty()) {
					n1 = 0;
				} else {
					n1 = a.getIdParkingFixedwing().size();
				}
				System.out.println("Number of Fixed-wing Airplanes in the Airport: " + n1);
				System.out.println("Helicopter Capacity: " + a.getMaxParkingRotatedwing());
				int n2;
				if (a.getIdParkingHelicopter() == null || a.getIdParkingHelicopter().isEmpty()) {
					n2 = 0;
				} else {
					n2 = a.getIdParkingHelicopter().size();
				}
				System.out.println("Number of Helicopters in the Airport: " + n2);
			}
		}
	}

	public void displayFixedwingAirplane() {
		if (fixedwing.isEmpty()) {
			System.out.println("There are no fixed-wing airplanes created!");
		} else {
			System.out.printf("%-10s%-40s%-15s%-15s%-15s%-20s%-20s%-15s%-20s%-15s", "ID", "Model", "Plane Type",
					"Cruise Speed", "Empty Weight", "Max Takeoff Weight", "Min Runway Size", "Fly Method",
					"Parking Airport ID", "Airport's Name");
			System.out.println("");
			for (Fixedwing f : fixedwing) {
				int n = findAirplane(f.getId());
				f.display();
				if (n == -1) {
					System.out.printf("%-20s%-15s", "None", "None");
					System.out.println("");
				} else {
					System.out.printf("%-20s%-15s", airport.get(n).getId(), airport.get(n).getName());
					System.out.println("");
				}
			}
		}
	}

	public int findAirplane(String id) {
		if (airport.isEmpty()) {
			return -1;
		} else {
			List<String> listFixedwing;
			for (int i = 0; i < airport.size(); i++) {
				listFixedwing = airport.get(i).getIdParkingFixedwing();
				int count = 0;
				if (listFixedwing == null || listFixedwing.isEmpty())
					;
				else {
					for (String s : listFixedwing) {
						if (s.equals(id)) {
							count++;
						}
					}
				}
				if (count != 0) {
					return i;
				}
			}
			return -1;
		}
	}

	public void displayHelicopter() {
		if (helicopter.isEmpty()) {
			System.out.println("There are no helicopters created!");
		} else {
			System.out.printf("%-10s%-40s%-15s%-15s%-20s%-20s%-15s%-20s%-15s", "ID", "Model", "Cruise Speed",
					"Empty Weight", "Max Takeoff Weight", "Range", "Fly Method", "Parking Airport ID",
					"Airport's Name");
			System.out.println("");
			for (Helicopter h : helicopter) {
				int n = findHelicopter(h.getId());
				h.display();
				if (n == -1) {
					System.out.printf("%-20s%-15s", "None", "None");
					System.out.println("");
				} else {
					System.out.printf("%-20s%-15s", airport.get(n).getId(), airport.get(n).getName());
					System.out.println("");
				}
			}
		}
	}

	public int findHelicopter(String id) {
		if (airport.isEmpty()) {
			return -1;
		} else {
			List<String> listHelicopter;
			for (int i = 0; i < airport.size(); i++) {
				listHelicopter = airport.get(i).getIdParkingHelicopter();
				int count = 0;
				if (listHelicopter == null || listHelicopter.isEmpty())
					;
				else {
					for (String s : listHelicopter) {
						if (s.equals(id)) {
							count++;
						}
					}
				}
				if (count != 0) {
					return i;
				}
			}
			return -1;
		}
	}

	public void addFixedWing() {
		if (airport.isEmpty()) {
			System.out.println("There are no airports created!");
		} else if (fixedwing.isEmpty()) {
			System.out.println("There are no fixed-wing airplanes created!");
		} else {
			List<String> airportID = new ArrayList<>();
			List<String> fixedwingID = new ArrayList<>();
			for (Airport a : airport) {
				if (a.getIdParkingFixedwing() == null
						|| a.getIdParkingFixedwing().size() < a.getMaxParkingFixedwing()) {
					airportID.add(a.getId());
				}
				if (a.getIdParkingFixedwing() != null) {
					List<String> fixedwingPark = a.getIdParkingFixedwing();
					for (String s : fixedwingPark) {
						fixedwingID.add(s);
					}
				}
			}
			if (airportID.isEmpty()) {
				System.out.println("There are no available airports!");
			} else if (fixedwingID.size() == fixedwing.size()) {
				System.out.println("All fixed-wing airplanes are parked!");
			} else {
				List<String> fixedwingAvailable = new ArrayList<>();
				for (Fixedwing f : fixedwing) {
					if (!fixedwingID.contains(f.getId())) {
						fixedwingAvailable.add(f.getId());
					}
				}
				System.out.println("\nAVAILABLE AIRPORTS:");
				System.out.printf("%-10s%-20s%-15s%-30s%-30s%-30s%-30s", "ID", "Name", "Runway Size",
						"Fixed-wing Parking Capacity", "Fixed-wing's ID List", "Helicopter Parking Capacity",
						"Helicopter's ID List");
				for (String s : airportID) {
					System.out.println("");
					Airport a = airport.get(checkIDAirport(s));
					a.display();
				}
				System.out.println("\n\nAVAILABLE FIXED-WING AIRPLANES:");
				System.out.printf("%-10s%-40s%-15s%-15s%-15s%-20s%-20s%-15s", "ID", "Model", "Plane Type",
						"Cruise Speed", "Empty Weight", "Max Takeoff Weight", "Min Runway Size", "Fly Method");
				for (String s : fixedwingAvailable) {
					System.out.println("");
					Fixedwing a = fixedwing.get(checkIDFixedWing(s));
					a.display();
				}
				System.out.print("\n\nChoose an airport, enter its ID: ");
				String id = Validator.checkValidIDAirport();
				while (!airportID.contains(id)) {
					System.err.println("Please enter an airport in the list!");
					System.out.print("Enter again: ");
					id = Validator.checkValidIDAirport();
				}
				System.out.println("\nSUITABLE AIRPLANES WITH THIS AIRPORT:");
				List<String> available = new ArrayList<>();
				double runwaySize = airport.get(checkIDAirport(id)).getRunwaySize();
				for (String s : fixedwingAvailable) {
					if (fixedwing.get(checkIDFixedWing(s)).getMinRunwaySize() < runwaySize) {
						available.add(s);
					}
				}
				if (available.isEmpty()) {
					System.out.println("There are no suitable airplanes!");
				} else {
					for (String s : available) {
						System.out.println("ID: " + s + " - " + "Min Runway Size: "
								+ fixedwing.get(checkIDFixedWing(s)).getMinRunwaySize());
					}
					System.out.print("\nChoose an airplane, enter its ID: ");
					String id2 = Validator.checkValidIDFixedwing();
					while (!available.contains(id2)) {
						System.err.println("Please enter an airplane in the list!");
						System.out.print("Enter again: ");
						id2 = Validator.checkValidIDFixedwing();
					}
					List<String> updatedParking = new ArrayList<>();
					if (airport.get(checkIDAirport(id)).getIdParkingFixedwing() == null
							|| airport.get(checkIDAirport(id)).getIdParkingFixedwing().isEmpty())
						;
					else {
						updatedParking = airport.get(checkIDAirport(id)).getIdParkingFixedwing();
					}
					updatedParking.add(id2);
					airport.get(checkIDAirport(id)).setIdParkingFixedwing(updatedParking);

					System.out.println("Airplane's status updated!");
				}
			}
		}
	}

	public void removeFixedWing() {
		if (airport.isEmpty()) {
			System.out.println("There are no airports created!");
		} else {
			List<String> airportID = new ArrayList<>();
			for (Airport a : airport) {
				if (a.getIdParkingFixedwing() == null || a.getIdParkingFixedwing().isEmpty())
					;
				else {
					airportID.add(a.getId());
				}
			}
			if (airportID.isEmpty()) {
				System.out.println("There are no fixed-wing airplanes in airports!");
			} else {
				System.out.printf("%-10s%-20s%-15s%-30s%-30s%-30s%-30s", "ID", "Name", "Runway Size",
						"Fixed-wing Parking Capacity", "Fixed-wing's ID List", "Helicopter Parking Capacity",
						"Helicopter's ID List");
				for (String s : airportID) {
					System.out.println("");
					Airport a = airport.get(checkIDAirport(s));
					a.display();
				}
				System.out.print("\nChoose an airport, enter its ID: ");
				String id = Validator.checkValidIDAirport();
				while (!airportID.contains(id)) {
					System.err.println("Please enter an airport in the list!");
					System.out.print("Enter again: ");
					id = Validator.checkValidIDAirport();
				}
				System.out.print("\nAirport ID: " + id + " - Fixed-wing Airplanes ID: ");
				List<String> fixedwingID = airport.get(checkIDAirport(id)).getIdParkingFixedwing();
				for (String item : fixedwingID) {
					System.out.print(item + " ");
				}
				System.out.print("\nEnter a fixed-wing airplane ID to remove: ");
				String id2 = Validator.checkValidIDFixedwing();
				while (!fixedwingID.contains(id2)) {
					System.err.println("Please enter an airplane in the list!");
					System.out.print("Enter again: ");
					id2 = Validator.checkValidIDFixedwing();
				}
				for (int i = 0; i < fixedwingID.size(); i++) {
					if (fixedwingID.get(i).equals(id2))
						fixedwingID.remove(i);
				}
				airport.get(checkIDAirport(id)).setIdParkingFixedwing(fixedwingID);
				System.out.println("Airplane Removed!");
			}
		}
	}

	public void addHelicopter() {
		if (airport.isEmpty()) {
			System.out.println("There are no airports created!");
		} else if (helicopter.isEmpty()) {
			System.out.println("There are no helicopters created!");
		} else {
			List<String> airportID = new ArrayList<>();
			List<String> helicopterID = new ArrayList<>();
			for (Airport a : airport) {
				if (a.getIdParkingHelicopter() == null
						|| a.getIdParkingHelicopter().size() < a.getMaxParkingRotatedwing()) {
					airportID.add(a.getId());
				}
				if (a.getIdParkingHelicopter() != null) {
					List<String> helicopterPark = a.getIdParkingHelicopter();
					for (String s : helicopterPark) {
						helicopterID.add(s);
					}
				}
			}
			if (airportID.isEmpty()) {
				System.out.println("There are no available airports!");
			} else if (helicopterID.size() == helicopter.size()) {
				System.out.println("All helicopters are parked!");
			} else {
				List<String> helicopterAvailable = new ArrayList<>();
				for (Helicopter h : helicopter) {
					if (!helicopterID.contains(h.getId())) {
						helicopterAvailable.add(h.getId());
					}
				}
				System.out.println("\nAVAILABLE AIRPORTS:");
				System.out.printf("%-10s%-20s%-15s%-30s%-30s%-30s%-30s", "ID", "Name", "Runway Size",
						"Fixed-wing Parking Capacity", "Fixed-wing's ID List", "Helicopter Parking Capacity",
						"Helicopter's ID List");
				for (String s : airportID) {
					System.out.println("");
					Airport a = airport.get(checkIDAirport(s));
					a.display();
				}
				System.out.println("\n\nAVAILABLE HELICOPTERS:");
				System.out.printf("%-10s%-40s%-15s%-15s%-20s%-20s%-15s", "ID", "Model", "Cruise Speed", "Empty Weight",
						"Max Takeoff Weight", "Range", "Fly Method");
				for (String s : helicopterAvailable) {
					System.out.println("");
					Helicopter a = helicopter.get(checkIDHelicopter(s));
					a.display();
				}
				System.out.print("\n\nChoose an airport, enter its ID: ");
				String id = Validator.checkValidIDAirport();
				while (!airportID.contains(id)) {
					System.err.println("Please enter an airport in the list!");
					System.out.print("Enter again: ");
					id = Validator.checkValidIDAirport();
				}
				System.out.println("\nAVAILABLE HELICOPTERS:");
				System.out.printf("%-10s%-40s%-15s%-15s%-20s%-20s%-15s", "ID", "Model", "Cruise Speed", "Empty Weight",
						"Max Takeoff Weight", "Range", "Fly Method");
				for (String s : helicopterAvailable) {
					System.out.println("");
					Helicopter a = helicopter.get(checkIDHelicopter(s));
					a.display();
				}
				System.out.print("\nChoose an airplane, enter its ID: ");
				String id2 = Validator.checkValidIDHelicopter();
				while (!helicopterAvailable.contains(id2)) {
					System.err.println("Please enter an airplane in the list!");
					System.out.print("Enter again: ");
					id2 = Validator.checkValidIDHelicopter();
				}
				List<String> updatedParking = new ArrayList<>();
				if (airport.get(checkIDAirport(id)).getIdParkingHelicopter() == null
						|| airport.get(checkIDAirport(id)).getIdParkingHelicopter().isEmpty())
					;
				else {
					updatedParking = airport.get(checkIDAirport(id)).getIdParkingHelicopter();
				}
				updatedParking.add(id2);
				airport.get(checkIDAirport(id)).setIdParkingHelicopter(updatedParking);

				System.out.println("Airplane's status updated!");
			}
		}
	}

	public void removeHelicopter() {
        if (airport.isEmpty()) {
            System.out.println("There are no airports created!");
        } else {
            List<String> airportID = new ArrayList<>();
            for (Airport a : airport) {
                if (a.getIdParkingHelicopter()== null || a.getIdParkingHelicopter().isEmpty()); else {
                    airportID.add(a.getId());
                }
            }
            if (airportID.isEmpty()) {
                System.out.println("There are no helicopters in airports!");
            } else {
                System.out.printf("%-10s%-20s%-15s%-30s%-30s%-30s%-30s", "ID", "Name", "Runway Size", "Fixed-wing Parking Capacity", "Fixed-wing's ID List", "Helicopter Parking Capacity", "Helicopter's ID List");
                for (String s : airportID) {
                    System.out.println("");
                    Airport a = airport.get(checkIDAirport(s));
                    a.display();
                }
                System.out.print("\nChoose an airport, enter its ID: ");
                String id = Validator.checkValidIDAirport();
                while (!airportID.contains(id)) {
                    System.err.println("Please enter an airport in the list!");
                    System.out.print("Enter again: ");
                    id = Validator.checkValidIDAirport();
                }
                System.out.print("\nAirport ID: " + id + " - Helicopter ID: ");
                List<String> helicopterID = airport.get(checkIDAirport(id)).getIdParkingHelicopter();
                for (String item : helicopterID) {
                    System.out.print(item + " ");
                }
                System.out.print("\nEnter a helicopter ID to remove: ");
                String id2 = Validator.checkValidIDHelicopter();
                while (!helicopterID.contains(id2)) {
                    System.err.println("Please enter an airplane in the list!");
                    System.out.print("Enter again: ");
                    id2 = Validator.checkValidIDHelicopter();
                }
                /*for (String s : fixedwingID) {
                    if (s.equals(id2)) fixedwingID.remove(s);
                }*/
                for (int i = 0; i < helicopterID.size(); i++) {
                    if (helicopterID.get(i).equals(id2)) helicopterID.remove(i);
                }
                airport.get(checkIDAirport(id)).setIdParkingHelicopter(helicopterID);
                System.out.println("Airplane Removed!");
            }
        }
    }
	
	public void updateFixedWing() {
        if (fixedwing.isEmpty()) System.out.println("There are no fixed-wing airplanes created!");
        else {
            displayFixedwingAirplane();
            System.out.print("\nEnter fixed-wing airplane ID to update: ");
            String id = Validator.checkValidIDFixedwing();
            while (checkIDFixedWing(id) == -1) {
                System.err.println("Please enter an airplane in the list!");
                System.out.print("Enter again: ");
                id = Validator.checkValidIDAirport();
            }
            int index = checkIDFixedWing(id);
            System.out.print("Enter updated plane type (CAG: Cargo, LGR: Long range, PRV: Private): ");
            String type = Validator.checkValidFixedwingType();
            System.out.print("Enter updated airplane's min needed runway size: ");
            double runwaySize = Validator.checkInputPositive();
            fixedwing.get(index).setPlaneType(type);
            fixedwing.get(index).setMinRunwaySize(runwaySize);
            System.out.println("Information updated!");
        }
    }
	
	public void save() {
        File file = new File("AirplaneManagement.dat");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file);
            fw.write("Fixed-wing Airplanes:\n");
            for (Fixedwing f : fixedwing) {
                String data = f.toString();
                fw.write(data + "\n");
            }
            fw.write("\nHelicopters:\n");
            for (Helicopter h : helicopter) {
                String data = h.toString();
                fw.write(data + "\n");
            }
            fw.write("\nAirports:\n");
            for (Airport a : airport) {
                String data = a.toString();
                fw.write(data + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println("File is saved!!");
    }
	
	public void mainMenu() {
        System.out.println("\n******************************");
        System.out.println("AIRPLANE MANAGEMENT");
        System.out.println("- Input data from keyboard:");
        System.out.println("\t1. Add a fixed-wing airplane");
        System.out.println("\t2. Add a helicopter (rotated-wing airplane)");
        System.out.println("\t3. Add an airport");
        System.out.println("- Airport management:");
        System.out.println("\t4. Display all airports (sorted by ID)");
        System.out.println("\t5. Display the status of one airport");
        System.out.println("- Fixed-wing airplane management:");
        System.out.println("\t6. Display all fixed-wing airplanes");
        System.out.println("- Helicopter management:");
        System.out.println("\t7. Display all helicopters");
        System.out.println("8. Exit");
        System.out.println("******************************");
        System.out.println("FUNCTIONAL REQUIREMEMTS");
        System.out.println("\t9. Add fixed-wing airplanes to an airport");
        System.out.println("\t10. Remove fixed-wing airplanes from an airport");
        System.out.println("\t11. Add helicopters to an airport");
        System.out.println("\t12. Remove helicopters from an airport");
        System.out.println("\t13. Update plane type and min needed runway size of fixed-wing airplane");
        System.out.println("\t14. Save into text file");
        System.out.print("Enter your choice: ");
    }
}
