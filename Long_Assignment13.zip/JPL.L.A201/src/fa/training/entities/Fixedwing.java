/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public class Fixedwing extends Airplane {
	private String planeType;
    private double minRunwaySize;
    private final String flyMethod = "Fixed wing";
    
    public Fixedwing() {
		// TODO Auto-generated constructor stub
	}

	public Fixedwing(String id, String model, double cruiseSpeed, double emptyWeight, double maxTakeOffWeight,
			String planeType, double minRunwaySize) {
		super(id, model, cruiseSpeed, emptyWeight, maxTakeOffWeight);
		this.planeType = planeType;
		this.minRunwaySize = minRunwaySize;
	}

	public String getPlaneType() {
		return planeType;
	}

	public void setPlaneType(String planeType) {
		this.planeType = planeType;
	}

	public double getMinRunwaySize() {
		return minRunwaySize;
	}

	public void setMinRunwaySize(double minRunwaySize) {
		this.minRunwaySize = minRunwaySize;
	}

	public String getFlyMethod() {
		return flyMethod;
	}

	@Override
	public String toString() {
		return "Fixedwing [planeType=" + planeType + ", minRunwaySize=" + minRunwaySize + ", flyMethod=" + flyMethod
				+ ", id=" + id + ", model=" + model + ", cruiseSpeed=" + cruiseSpeed + ", emptyWeight=" + emptyWeight
				+ ", maxTakeOffWeight=" + maxTakeOffWeight + "]";
	}
    
    public void display() {
		System.out.println("Fixedwing [planeType=" + planeType + ", minRunwaySize=" + minRunwaySize + ", flyMethod=" + flyMethod
				+ ", id=" + id + ", model=" + model + ", cruiseSpeed=" + cruiseSpeed + ", emptyWeight=" + emptyWeight
				+ ", maxTakeOffWeight=" + maxTakeOffWeight + "]");
	}
}
