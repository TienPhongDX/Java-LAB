/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public class Helicopter extends Airplane {
	private double range;
    private final String flyMethod = "Rotated wing";
    
    public Helicopter() {
		// TODO Auto-generated constructor stub
	}

	public Helicopter(String id, String model, double cruiseSpeed, double emptyWeight, double maxTakeOffWeight,
			double range) {
		super(id, model, cruiseSpeed, emptyWeight, maxTakeOffWeight);
		this.range = range;
	}

	public double getRange() {
		return range;
	}

	public void setRange(double range) {
		this.range = range;
	}

	public String getFlyMethod() {
		return flyMethod;
	}

	@Override
	public String toString() {
		return "Helicopter [range=" + range + ", flyMethod=" + flyMethod + ", id=" + id + ", model=" + model
				+ ", cruiseSpeed=" + cruiseSpeed + ", emptyWeight=" + emptyWeight + ", maxTakeOffWeight="
				+ maxTakeOffWeight + "]";
	}

    public void display() {
		System.out.println("Helicopter [range=" + range + ", flyMethod=" + flyMethod + ", id=" + id + ", model=" + model
				+ ", cruiseSpeed=" + cruiseSpeed + ", emptyWeight=" + emptyWeight + ", maxTakeOffWeight="
				+ maxTakeOffWeight + "]");
	}
    
    
}
