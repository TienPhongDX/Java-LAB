/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.util.ArrayList;
import java.util.List;

public class Airport implements Comparable<Airport>{
	private String id, name;
    private double runwaySize;
    private int maxParkingFixedwing;
    private List<String> idParkingFixedwing = new ArrayList<>();
    private int maxParkingRotatedwing;
    private List<String> idParkingHelicopter = new ArrayList<>();
    
    public Airport() {
		// TODO Auto-generated constructor stub
	}

	public Airport(String id, String name, double runwaySize, int maxParkingFixedwing, List<String> idParkingFixedwing,
			int maxParkingRotatedwing, List<String> idParkingHelicopter) {
		super();
		this.id = id;
		this.name = name;
		this.runwaySize = runwaySize;
		this.maxParkingFixedwing = maxParkingFixedwing;
		this.idParkingFixedwing = idParkingFixedwing;
		this.maxParkingRotatedwing = maxParkingRotatedwing;
		this.idParkingHelicopter = idParkingHelicopter;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getRunwaySize() {
		return runwaySize;
	}

	public void setRunwaySize(double runwaySize) {
		this.runwaySize = runwaySize;
	}

	public int getMaxParkingFixedwing() {
		return maxParkingFixedwing;
	}

	public void setMaxParkingFixedwing(int maxParkingFixedwing) {
		this.maxParkingFixedwing = maxParkingFixedwing;
	}

	public List<String> getIdParkingFixedwing() {
		return idParkingFixedwing;
	}

	public void setIdParkingFixedwing(List<String> idParkingFixedwing) {
		this.idParkingFixedwing = idParkingFixedwing;
	}

	public int getMaxParkingRotatedwing() {
		return maxParkingRotatedwing;
	}

	public void setMaxParkingRotatedwing(int maxParkingRotatedwing) {
		this.maxParkingRotatedwing = maxParkingRotatedwing;
	}

	public List<String> getIdParkingHelicopter() {
		return idParkingHelicopter;
	}

	public void setIdParkingHelicopter(List<String> idParkingHelicopter) {
		this.idParkingHelicopter = idParkingHelicopter;
	}

	@Override
	public String toString() {
		return "Airport [id=" + id + ", name=" + name + ", runwaySize=" + runwaySize + ", maxParkingFixedwing="
				+ maxParkingFixedwing + ", idParkingFixedwing=" + idParkingFixedwing + ", maxParkingRotatedwing="
				+ maxParkingRotatedwing + ", idParkingHelicopter=" + idParkingHelicopter + "]";
	}
    
    @Override
    public int compareTo(Airport p) {
    	// TODO Auto-generated method stub
    	return this.id.compareTo(p.id);
    }
    
    public void display() {
		String park1 = "", park2 = "";
		
		if (getIdParkingFixedwing() == null || getIdParkingFixedwing().isEmpty()) {
			park1 = "Empty!";
		} else {
			for (String idFW : this.idParkingFixedwing) {
				park1.concat(idFW + " "); 
			}
		}
		
		if (getIdParkingHelicopter() == null || getIdParkingHelicopter().isEmpty()) {
			park2 = "Empty!";
		} else {
			for (String idH : idParkingHelicopter) {
				park2.concat(idH+" ");
			}
		}
		
		System.out.printf("%-10s%-20s%-15f%-30d%-30s%-30d%-30s", this.id, this.name, this.runwaySize, this.maxParkingFixedwing, park1, this.maxParkingRotatedwing, park2);
	}
}
