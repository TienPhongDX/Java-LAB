/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 3 thg 3, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.util.Scanner;

public class Validator {
public final static Scanner in = new Scanner(System.in);
    
    public static int checkInputInt() {
        while (true) {
            try {
                int result = Integer.parseInt(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be integer! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static double checkInputDouble() {
        while (true) {
            try {
                double result = Double.parseDouble(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be double! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static String checkInputString() {
        while(true){
            String result = in.nextLine().trim();
            if (result.isEmpty()){
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static int checkInputLimit(int min, int max){
        while(true){
            int result = checkInputInt();
            if (result >= min && result <= max) return result;
            else{
                System.err.println("Please input number from "+min+" to "+max+"!");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static double checkInputPositive(){
        while(true){
            double result = checkInputDouble();
            if (result > 0) return result;
            else{
                System.err.println("Please input a number > 0!");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static int checkInputIntPositive(){
        while(true){
            int result = checkInputInt();
            if (result > 0) return result;
            else{
                System.err.println("Please input a number > 0!");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static boolean checkInputYN() {
        while (true) {
            String result = Validator.checkInputString();
            if (result.equalsIgnoreCase("Y")) return true;
            else if (result.equalsIgnoreCase("N")) return false;
        System.err.println("Please input y/Y or n/N.");
        System.out.print("Enter again: ");
        }
    }
    
    public static String checkValidIDFixedwing() {
        //String regex = "/[0-9]{10}/";
        while(true){
            String result = checkInputString();
            if (result.length() != 7) {
                System.err.println("Please input a valid fixed-wing airplane ID! (contains 7 characters, starts with \"FW\" and followed by 5 digits)");
                System.out.print("Enter again: ");
            }
            else if (!result.substring(0, 2).equals("FW") || !result.substring(2).matches("\\d+")) {
                System.err.println("Please input a valid fixed-wing airplane ID! (contains 7 characters, starts with \"FW\" and followed by 5 digits)");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkValidIDHelicopter() {
        //String regex = "/[0-9]{10}/";
        while(true){
            String result = checkInputString();
            if (result.length() != 7) {
                System.err.println("Please input a valid helicopter ID! (contains 7 characters, starts with \"RW\" and followed by 5 digits)");
                System.out.print("Enter again: ");
            }
            else if (!result.substring(0, 2).equals("RW") || !result.substring(2).matches("\\d+")) {
                System.err.println("Please input a valid helicopter ID! (contains 7 characters, starts with \"RW\" and followed by 5 digits)");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkValidIDAirport() {
        //String regex = "/[0-9]{10}/";
        while(true){
            String result = checkInputString();
            if (result.length() != 7) {
                System.err.println("Please input a valid airport ID! (contains 7 characters, starts with \"AP\" and followed by 5 digits)");
                System.out.print("Enter again: ");
            }
            else if (!result.substring(0, 2).equals("AP") || !result.substring(2).matches("\\d+")) {
                System.err.println("Please input a valid airport ID! (contains 7 characters, starts with \"AP\" and followed by 5 digits)");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkValidModel() {
        //String regex = "/[0-9]{10}/";
        while(true){
            String result = checkInputString();
            if (result.length() > 40) {
                System.err.println("Please input a valid airplane model! (maximum: 40 characters)");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static String checkValidFixedwingType() {
        //String regex = "/[0-9]{10}/";
        while(true){
            String result = checkInputString().toUpperCase();
            if (!result.equalsIgnoreCase("CAG") && !result.equalsIgnoreCase("LGR") && !result.equalsIgnoreCase("PRV")) {
                System.err.println("This field only accpets 'CAG', 'LGR' and 'PRV'");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static double checkValidHelicopterTakeoffWeight(double emptyWeight) {
        while(true){
            double  result = checkInputPositive();
            if (result > emptyWeight * 1.5) {
                System.err.println("Takeoff weight does not excess 1.5 times of its empty weight! (" + emptyWeight + " < Takeoff weight <= " + (emptyWeight * 1.5) + ")");
                System.out.print("Enter again: ");
            }
            else if (result <= emptyWeight) {
                System.err.println("Takeoff weight must greater than its empty weight: " + emptyWeight + "!");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static double checkValidFixedWingTakeoffWeight(double emptyWeight) {
        while(true){
            double  result = checkInputPositive();
            if (result <= emptyWeight) {
                System.err.println("Takeoff weight must greater than its empty weight: " + emptyWeight + "!");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
}
