/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Validator {
public final static Scanner in = new Scanner(System.in);
    
    public static int checkInputInt() {
        while (true) {
            try {
                int result = Integer.parseInt(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be integer! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static double checkInputDouble() {
        while (true) {
            try {
                double result = Double.parseDouble(in.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Inputted string must be double! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    public static Date checkInputDate() {
        SimpleDateFormat ft = new SimpleDateFormat ("dd/MM/yyyy");    

        while (true) {
            try {
                Date result = ft.parse(in.nextLine().trim());
                return result;
            } catch (ParseException e) {
                System.err.println("Inputted string must be a date (dd/MM/yyyy)! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static String checkInputString() {
        while(true){
            String result = in.nextLine().trim();
            if (result.isEmpty()){
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            }
            else return result;
        }
    }
    
    public static int checkInputLimit(int min, int max){
        while(true){
            int result = Integer.parseInt(in.nextLine().trim());
            if (result >= min && result <= max) return result;
            else{
                System.err.println("Please input number from "+min+" to "+max+"!");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static int checkInputPositive(){
        while(true){
            int result = Integer.parseInt(in.nextLine().trim());
            if (result > 0) return result;
            else{
                System.err.println("Please input a number > 0!");
                System.out.print("Enter again: ");
            }
        }
    }
}
