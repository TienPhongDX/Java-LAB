/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import fa.training.entities.Book;
import fa.training.entities.Magazine;
import fa.training.entities.Publication;

public class Manager {
	List<Publication> list = new ArrayList<>();
    List<Book> book = new ArrayList<>();
    List<Magazine> magazine = new ArrayList<>();

    public void addBook() {
        System.out.println("Enter publication year: ");
        int year = Validator.checkInputInt();
        System.out.println("Enter publisher: ");
        String publisher = Validator.checkInputString();
        System.out.println("Enter publication date: ");
        Date date = Validator.checkInputDate();
        System.out.println("Enter ISBN: ");
        String isbn = Validator.checkInputString();
        System.out.println("Enter number of authors of the book: ");
        int n = Validator.checkInputInt();
        Set<String> author = new HashSet<>();
        for (int i = 0; i < n; i++) {
            System.out.println("Enter author " + (i + 1) + ": ");
            String name = Validator.checkInputString();
            author.add(name);
        }
        System.out.println("Enter publication place: ");
        String place = Validator.checkInputString();
        Book b = new Book(year, publisher, date, isbn, author, place);
        list.add(b);
        System.out.println("New book added!\n");
    }

    public void addMagazine() {
        System.out.println("\nEnter publication year: ");
        int year = Validator.checkInputInt();
        System.out.println("Enter publisher: ");
        String publisher = Validator.checkInputString();
        System.out.println("Enter publication date: ");
        Date date = Validator.checkInputDate();
        System.out.println("Enter author: ");
        String author = Validator.checkInputString();
        System.out.println("Enter volumn: ");
        int volumn = Validator.checkInputInt();
        System.out.println("Enter edition: ");
        int edition = Validator.checkInputInt();
        Magazine m = new Magazine(year, publisher, date, author, volumn, edition);
        list.add(m);
        System.out.println("New magazine added!\n");
    }

    public void display() {
        if (list.isEmpty()) {
            System.out.println("The list is empty!");
        } else {
            Map<Integer, List<String>> map = new Hashtable();
            for (Publication publication : list) {
                int year = publication.getPublicationYear();
                String publisher = publication.getPublisher();
                if (!map.containsKey(year)) {
                    List<String> pubList = new ArrayList<>();
                    pubList.add(publisher);
                    map.put(year, pubList);
                } else {
                    List<String> pubList = map.get(year);
                    int count = 0;
                    for (String string : pubList) {
                        if (string.equals(publisher)) {
                            count++;
                        }
                    }
                    if (count == 0) {
                        pubList.add(publisher);
                        map.replace(year, pubList);
                    }
                }
            }

            Set<Map.Entry<Integer, List<String>>> setMap = map.entrySet();
            for (Map.Entry<Integer, List<String>> entry : setMap) {
                List<String> pubList = entry.getValue();
                for (String publisher : pubList) {
                    List<Publication> finalList = new ArrayList<>();
                    for (Publication publication : list) {
                        if (publication.getPublicationYear() == entry.getKey() && publication.getPublisher().equals(publisher)) {
                            finalList.add(publication);
                        }
                    }
                    if (finalList.size() >= 2) {
                        System.out.println("\nList of Books & Magazines that have Publication Year = " + entry.getKey() + " & Publisher = " + publisher + ":-------------------");
                        for (Publication publication : finalList) {
                            if (publication instanceof Book) {
                                Book b = (Book) publication;
                                b.display();
                            } else {
                                Magazine m = (Magazine) publication;
                                m.display();
                            }
                        }
                    }
                }
            }
        }
    }

    public void addAuthor() {
        List<Integer> index = new ArrayList<>();
        int num;
        for (Publication publication : list) {
            if (publication instanceof Book) {
                int order = list.indexOf(publication);
                System.out.println("\nNUMERICAL ORDER: " + (order + 1) + "------------------");
                publication.display();
                index.add(order + 1);
            }
        }
        if (index.isEmpty()) {
            System.out.println("\nThere are no books in this list!");
        } else {
            System.out.println("\nEnter book's numerical order: ");
            num = Validator.checkInputInt();
            while (true) {
                if (!index.contains(num)) {
                    System.err.println("Numerical Order is not available!");
                    System.out.println("Enter again: ");
                    num = Validator.checkInputInt();
                } else {
                    break;
                }
            }
            System.out.println("BOOK IS FOUND!");
            Publication p = list.get(num - 1);
            p.display();
            Book b = (Book) p;
            int flag;
            Set<String> authorList = b.getAuthor();
            System.out.println("Enter new author's name: ");
            String newAuthor = Validator.checkInputString();
            while (true) {
                flag = 0;
                for (String authorName : authorList) {
                    if (authorName.equals(newAuthor)) {
                        flag++;
                    }
                }
                if (flag != 0) {
                    System.err.println("Author existed!");
                    System.out.println("Enter again: ");
                    newAuthor = Validator.checkInputString();
                } else {
                    break;
                }
            }
            authorList.add(newAuthor);
            b.setAuthor(authorList);
            list.set(num - 1, b);
            System.out.println("AUTHOR ADDED SUCESSFULLY!");
        }
    }

    public void top10() {
        List<Magazine> magazineSortedList = new ArrayList<>();
        for (Publication publication : list) {
            if (publication instanceof Magazine) {
                magazineSortedList.add((Magazine) publication);
            }
        }
        Collections.sort(magazineSortedList);
        int size = magazineSortedList.size();
        System.out.println("Top 10 of magazines by volumn: ");
        if (size < 10) {
            for (int i = 0; i < size; i++) {
                System.out.println("TOP " + (i + 1) + " ");
                magazineSortedList.get(i).display();
                System.out.println("");
            }
            System.out.println((size + 1) + ". Not available!");
            System.out.println("");
        } else {
            for (int i = 0; i < 10; i++) {
                System.out.println("TOP " + (i + 1) + " ");
                magazineSortedList.get(i).display();
                System.out.println("");
            }
        }
    }

    public void searchBook() {
        List<Book> book = new ArrayList<>();
        int op, count = 0;
        for (Publication pub : list) {
            if (pub instanceof Book) {
                book.add((Book) pub);
            }
        }
        if (book.isEmpty()) {
            System.out.println("There are no book in the list!");
        } else {
            searchMenu();
            op = Validator.checkInputLimit(1, 3);
            switch (op) {
                case 1:
                    System.out.println("Enter ISBN: ");
                    String isbn = Validator.checkInputString();
                    for (Book book1 : book) {
                        if (book1.getIsbn().equals(isbn)) {
                            book1.display();
                            count++;
                        }
                    }
                    if (count == 0) {
                        System.out.println("Found 0 result!");
                    }
                    break;
                case 2:
                    System.out.println("Enter author name: ");
                    String author = Validator.checkInputString();
                    for (Book book1 : book) {
                        if (book1.getAuthor().contains(author)) {
                            book1.display();
                            count++;
                        }
                    }
                    if (count == 0) {
                        System.out.println("Found 0 results!");
                    }
                    break;
                case 3:
                    System.out.println("Enter publisher: ");
                    String publisher = Validator.checkInputString();
                    for (Book book1 : book) {
                        if (book1.getPublisher().equalsIgnoreCase(publisher)) {
                            book1.display();
                            count++;
                        }
                    }
                    if (count == 0) {
                        System.out.println("Found 0 results!");
                    }
                    break;
            }
        }
    }

    public void menu() {
        System.out.println("\n******************************");
        System.out.println("LIBRARY MANAGEMENT SYSTEM");
        System.out.println("1. Add a book");
        System.out.println("2. Add a magazine");
        System.out.println("3. Display books and magazines that have the same publication year and publisher");
        System.out.println("4. Add author to book");
        System.out.println("5. Display top 10 of magazines by volumn");
        System.out.println("6. Search book by (isbn, author, publisher)");
        System.out.println("7. Exit");
        System.out.println("******************************");
        System.out.println("Enter your choice: ");
    }

    public void searchMenu() {
        System.out.println("1. Search by ISBN");
        System.out.println("2. Search by Author");
        System.out.println("3. Search by Publisher");
        System.out.println("Enter your choice: ");
    }
}
