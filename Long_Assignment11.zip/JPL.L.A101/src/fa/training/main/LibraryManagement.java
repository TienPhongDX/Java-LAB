/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import fa.training.manager.Manager;
import fa.training.manager.Validator;

public class LibraryManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager manager = new Manager();
        int choice;

        while (true) {
        	manager.menu();
            choice = Validator.checkInputLimit(1, 7);
            switch (choice) {
                case 1:
                    manager.addBook();
                    break;
                case 2:
                    manager.addMagazine();
                    break;
                case 3:
                    manager.display();
                    break;
                case 4:
                    manager.addAuthor();
                    break;
                case 5:
                    manager.top10();
                    break;
                case 6:
                    manager.searchBook();
                    break;
                case 7:
                    return;
            }
        }
	}
}
