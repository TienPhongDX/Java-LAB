/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Magazine extends Publication implements Comparable<Magazine>{
    SimpleDateFormat sDatefm = new SimpleDateFormat ("dd/MM/yyyy");
    private String author;
    private int volumn;
    private int edition;

    public Magazine() {
    }

    public Magazine(int publicationYear, String publisher, Date publicationDate, String author, int volumn, int edition) {
        super(publicationYear, publisher, publicationDate);
        this.author = author;
        this.volumn = volumn;
        this.edition = edition;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getVolumn() {
        return volumn;
    }

    public void setVolumn(int volumn) {
        this.volumn = volumn;
    }

    public int getEdition() {
        return edition;
    }

    public void setEdition(int edition) {
        this.edition = edition;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
    
    @Override
    public void display() {
        System.out.println("Magazine:");
        System.out.println("1. Publication Year: " + publicationYear);
        System.out.println("2. Publisher: " + publisher);
        System.out.println("3. Publication Date: " + sDatefm.format(publicationDate));
        System.out.println("4. Author: " + author);
        System.out.println("5. Volumn: " + volumn);
        System.out.println("6. Edition: " + edition);
    }
    /*
    @Override
    public int compareTo(Magazine m) {
        if (this.volumn == m.volumn) return this.publisher.compareTo(m.publisher);
        else return this.volumn >= m.volumn ? -1:0;
    }*/
    
    @Override
    public int compareTo(Magazine m) {
        return this.volumn >= m.volumn ? -1:0;
    }
}
