/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

public class Book extends Publication{
    SimpleDateFormat sDatefm = new SimpleDateFormat ("dd/MM/yyyy");
    private String isbn;
    private Set<String> author;
    private String publicationPlace;

    public Book() {
    }

    public Book(int publicationYear, String publisher, Date publicationDate, String isbn, Set<String> author, String publicationPlace) {
        super(publicationYear, publisher, publicationDate);
        this.isbn = isbn;
        this.author = author;
        this.publicationPlace = publicationPlace;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Set<String> getAuthor() {
        return author;
    }

    public void setAuthor(Set<String> author) {
        this.author = author;
    }

    public String getPublicationPlace() {
        return publicationPlace;
    }

    public void setPublicationPlace(String publicationPlace) {
        this.publicationPlace = publicationPlace;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
    
    @Override
    public void display() {
        System.out.println("Book:");
        System.out.println("1. Publication Year: " + publicationYear);
        System.out.println("2. Publisher: " + publisher);
        System.out.println("3. Publication Date: " + sDatefm.format(publicationDate));
        System.out.println("4. ISBN: " + isbn);
        System.out.println("5. Author: ");
        for (String au : author) { 
            System.out.println(au + ". ");
        }
        System.out.println("\n6. Publication Place: " + publicationPlace);
    }
}
