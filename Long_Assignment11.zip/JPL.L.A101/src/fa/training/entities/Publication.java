/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.util.Date;

import fa.training.manager.Validator;

public abstract class Publication {
	int publicationYear;
    String publisher;
    Date publicationDate;

    public Publication() {
    }

    public Publication(int publicationYear, String publisher, Date publicationDate) {
        this.publicationYear = publicationYear;
        this.publisher = publisher;
        this.publicationDate = publicationDate;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
    
    public abstract void display();
}
