/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package training.main;

import fa.training.utils.Manager;
import fa.training.utils.Validator;

public class EmployeeManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager manager = new Manager();
		int choice1, choice2, choice3;

		while (true) {
			manager.MainMenu();
			choice1 = Validator.checkInputLimit(1, 8);
			switch (choice1) {
			case 1:
				manager.empInputMenu();
				break;
			case 2:
				manager.display();
				break;
			case 3:
				manager.classify();
				break;
			case 4:
				manager.searchInputMenu();
				break;
			case 5:
				manager.report();
				break;
			case 6:
				manager.addDepartment();
				break;
			case 7:
				manager.save();
				break;
			case 8:

				return;
			}
		}
	}

}
