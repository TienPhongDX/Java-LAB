/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package training.entities;

import java.util.List;

public class Department {
	private String departmentName;
	private List<Employee> listOfEmployee;

	public Department() {
		// TODO Auto-generated constructor stub
	}

	public Department(String departmentName, List<Employee> listOfEmployee) {
		super();
		this.departmentName = departmentName;
		this.listOfEmployee = listOfEmployee;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public List<Employee> getListOfEmployee() {
		return listOfEmployee;
	}

	public void setListOfEmployee(List<Employee> listOfEmployee) {
		this.listOfEmployee = listOfEmployee;
	}

	public void display() {

		int empNum = 0;
		if (getListOfEmployee() == null || getListOfEmployee().isEmpty())
			empNum = 0;
		else
			empNum = getListOfEmployee().size();

		System.out.printf("%-30s%-20s", this.departmentName, empNum);
	}

	@Override
	public String toString() {
		return "Department [departmentName=" + departmentName + ", listOfEmployee=" + listOfEmployee + "]";
	}

}
