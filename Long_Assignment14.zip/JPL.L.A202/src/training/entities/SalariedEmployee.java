/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package training.entities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SalariedEmployee extends Employee {
	DateFormat dateFM = new SimpleDateFormat("dd/MM/yyyy");
	
	private double commisstionRate;
	private double grossSales;
	private double basicSalary;
	
	public SalariedEmployee() {
		// TODO Auto-generated constructor stub
	}	

	public SalariedEmployee(String sSN, String firstName, String lastName, Date birthDate, String phone, String email,
			double commisstionRate, double grossSales, double basicSalary) {
		super(sSN, firstName, lastName, birthDate, phone, email);
		this.commisstionRate = commisstionRate;
		this.grossSales = grossSales;
		this.basicSalary = basicSalary;
	}

	public double getCommisstionRate() {
		return commisstionRate;
	}

	public void setCommisstionRate(double commisstionRate) {
		this.commisstionRate = commisstionRate;
	}

	public double getGrossSales() {
		return grossSales;
	}

	public void setGrossSales(double grossSales) {
		this.grossSales = grossSales;
	}

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		String date = dateFM.format(getBirthDate());
        System.out.printf("%-10s%-20s%-20s%-20s%-20s%-40s%-20f%-15f%-15f", this.getSSN(), this.getFirstName(), this.getLastName(), date, this.getPhone(), this.getEmail(), this.commisstionRate, this.grossSales, this.basicSalary);
	}

	@Override
	public String toString() {
		return "SalariedEmployee [commisstionRate=" + commisstionRate + ", grossSales=" + grossSales + ", basicSalary="
				+ basicSalary + ", Employee Infomation = " + super.toString() + "]";
	}

	@Override
	public double getPaymentAmount() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
	
	
	
	

}
