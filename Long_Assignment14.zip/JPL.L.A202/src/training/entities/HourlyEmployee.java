/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 29 thg 1, 2021
 * Version: 1.0
 *
 */

package training.entities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HourlyEmployee extends Employee {
	DateFormat dateFM = new SimpleDateFormat("dd/MM/yyyy");
	private double rate;
	private double workingHour;

	public HourlyEmployee() {
		// TODO Auto-generated constructor stub
	}

	public HourlyEmployee(String sSN, String firstName, String lastName, Date birthDate, String phone, String email,
			double rate, double workingHour) {
		super(sSN, firstName, lastName, birthDate, phone, email);
		this.rate = rate;
		this.workingHour = workingHour;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getWorkingHour() {
		return workingHour;
	}

	public void setWorkingHour(double workingHour) {
		this.workingHour = workingHour;
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		String date = dateFM.format(getBirthDate());
        System.out.printf("%-10s%-20s%-20s%-20s%-20s%-40s%-15f%-15f", this.getSSN(), this.getFirstName(), this.getLastName(), date, this.getPhone(), this.getEmail(), this.rate, this.workingHour);
	}

	@Override
	public String toString() {
		return "HourlyEmployee [rate=" + rate + ", workingHour=" + workingHour + ", Employee Infomation =" + super.toString()
				+ "]";
	}

	@Override
	public double getPaymentAmount() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
	
}
