/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import training.entities.Department;
import training.entities.Employee;
import training.entities.HourlyEmployee;
import training.entities.SalariedEmployee;

public class Manager {
	List<Employee> employee = new ArrayList<>();
	List<Department> department = new ArrayList<>();
	int choice1, choice2;

	public static void MainMenu() {
		System.out.println("======LIBRARY MANAGEMENT SYSTEM======\n");
		System.out.println("1. Add an employee");
		System.out.println("2. Display employees");
		System.out.println("3. Classify employees");
		System.out.println("4. Search by (department, emp's name)");
		System.out.println("\nPlease choose function you'd like to do:");
	}

	public void empInputMenu() {
		if (department.isEmpty()) {
			System.out.println("No department available!");
		} else {
			System.out.println("======LIBRARY MANAGEMENT SYSTEM======\n");
			System.out.println("1. Input Salaried Employee");
			System.out.println("2. Input Hourly Employee");
			System.out.println("3. Return");
			System.out.println("\nPlease choose function you'd like to do:");
			choice1 = Validator.checkInputLimit(1, 2);
			switch (choice1) {
			case 1:

				break;
			case 2:

				break;

			default:
				break;
			}
		}
	}

	public void searchInputMenu() {
		if (employee.isEmpty())
			System.out.println("No employee available!");
		else {
			System.out.println("======LIBRARY MANAGEMENT SYSTEM======\n");
			System.out.println("1. Search by department's name");
			System.out.println("2. Search by employee's name");
			System.out.println("\nPlease choose function you'd like to do:");
			choice2 = Validator.checkInputLimit(1, 2);
			switch (choice2) {
			case 1:

				break;
			case 2:

				break;
			}
		}
	}

	public void addSalariedEmployee() {
		System.out.print("Enter ssn: ");
		String ssn = Validator.checkInputString();
		System.out.print("Enter first name: ");
		String firstName = Validator.checkInputString();
		System.out.print("Enter last name: ");
		String lastName = Validator.checkInputString();
		System.out.print("Enter birthdate: ");
		Date birthDate = Validator.checkInputDate();
		System.out.print("Enter phone number: ");
		String phone = Validator.checkPhone();
		System.out.print("Enter email: ");
		String email = Validator.checkMail();
		System.out.print("Enter commission rate: ");
		double commissionRate = Validator.checkInputLimitDouble(0, 1);
		System.out.print("Enter gross sales: ");
		double grossSales = Validator.checkInputPositive();
		System.out.print("Enter basic salary: ");
		double basicSalary = Validator.checkInputPositive();
		System.out.println("Available department(s):");
		for (Department d : department) {
			System.out.println("- " + d.getDepartmentName());
		}
		System.out.print("Enter department name: ");
		String departmentName = Validator.checkInputString();
		while (checkDepartment(departmentName) == -1) {
			System.err.println("Department name is not available!");
			System.out.print("Enter again: ");
			departmentName = Validator.checkInputString();
		}
		SalariedEmployee s = new SalariedEmployee(ssn, firstName, lastName, birthDate, phone, email, commissionRate,
				grossSales, basicSalary);
		employee.add(s);
		insertIntoDepartment(s, departmentName);
		System.out.println("New employee added!");
	}

	public int checkDepartment(String name) {
		if (department.isEmpty()) {
			return -1;
		} else {
			for (int i = 0; i < department.size(); i++) {
				if (department.get(i).getDepartmentName().equalsIgnoreCase(name)) {
					return i;
				}
			}
		}
		return -1;
	}

	public void insertIntoDepartment(Employee s, String departmentName) {
		List<Employee> working = new ArrayList<>();
		if (department.get(checkDepartment(departmentName)).getListOfEmployee() == null
				|| department.get(checkDepartment(departmentName)).getListOfEmployee().isEmpty())
			;
		else
			working = department.get(checkDepartment(departmentName)).getListOfEmployee();
		working.add(s);
		department.get(checkDepartment(departmentName)).setListOfEmployee(working);
	}

	public void addHourlyEmployee() {
		System.out.print("Enter ssn: ");
		String ssn = Validator.checkInputString();
		System.out.print("Enter first name: ");
		String firstName = Validator.checkInputString();
		System.out.print("Enter last name: ");
		String lastName = Validator.checkInputString();
		System.out.print("Enter birthdate: ");
		Date birthDate = Validator.checkInputDate();
		System.out.print("Enter phone number: ");
		String phone = Validator.checkPhone();
		System.out.print("Enter email: ");
		String email = Validator.checkMail();
		System.out.print("Enter rate: ");
		double rate = Validator.checkInputLimitDouble(0, 1);
		System.out.print("Enter working hours: ");
		double workingHours = Validator.checkInputPositive();
		System.out.println("Available department(s):");
		for (Department d : department) {
			System.out.println("- " + d.getDepartmentName());
		}
		System.out.print("Enter department name: ");
		String departmentName = Validator.checkInputString();
		while (checkDepartment(departmentName) == -1) {
			System.err.println("Department name is not available!");
			System.out.print("Enter again: ");
			departmentName = Validator.checkInputString();
		}
		HourlyEmployee h = new HourlyEmployee(ssn, firstName, lastName, birthDate, phone, email, rate, workingHours);
		employee.add(h);
		insertIntoDepartment(h, departmentName);
		System.out.println("New employee added!");
	}

	public void display() {
		if (employee.isEmpty())
			System.out.println("There are no employees!");
		else {
			for (Employee e : employee) {
				System.out.println(e);
			}
		}
	}

	public void classify() {
		if (employee.isEmpty())
			System.out.println("There are no employees!");
		else {
			System.out.println("\nSalaried Employee: ");
			System.out.printf("%-10s%-20s%-20s%-20s%-20s%-40s%-20s%-15s%-15s", "ssn", "First Name", "Last Name",
					"Birthdate", "Phone Number", "Email", "Commission Rate", "Gross Sales", "Basic Salary");
			System.out.println("");
			for (Employee e : employee) {
				if (e instanceof SalariedEmployee) {
					e.display();
					System.out.println("");
				}
			}
			System.out.println("\nHourly Employee: ");
			System.out.printf("%-10s%-20s%-20s%-20s%-20s%-40s%-15s%-15s", "ssn", "First Name", "Last Name", "Birthdate",
					"Phone Number", "Email", "Rate", "Working Hours");
			System.out.println("");
			for (Employee e : employee) {
				if (e instanceof HourlyEmployee) {
					e.display();
					System.out.println("");
				}
			}
		}
	}

	public void searchByDepartment() {
		System.out.println("Available department(s):");
		for (Department d : department) {
			System.out.println("- " + d.getDepartmentName());
		}
		System.out.print("Enter department name: ");
		String departmentName = Validator.checkInputString();
		while (checkDepartment(departmentName) == -1) {
			System.err.println("Department name is not available!");
			System.out.print("Enter again: ");
			departmentName = Validator.checkInputString();
		}
		List<Employee> working = new ArrayList<>();
		if (department.get(checkDepartment(departmentName)).getListOfEmployee() == null
				|| department.get(checkDepartment(departmentName)).getListOfEmployee().isEmpty())
			System.out.println("There are 0 employees in this department!");
		else {
			working = department.get(checkDepartment(departmentName)).getListOfEmployee();
			System.out.println("Found " + working.size() + " employee(s)!");
			for (Employee e : working) {
				System.out.println(e);
			}
		}
	}

	public void searchByName() {
		System.out.print("Enter last name to search: ");
		String name = Validator.checkInputString();
		List<Employee> list = new ArrayList<>();
		for (Employee e : employee) {
			if (e.getLastName().equalsIgnoreCase(name))
				list.add(e);
		}
		System.out.println("Found " + list.size() + " employee(s)!");
		if (!list.isEmpty()) {
			for (Employee e : list) {
				System.out.println(e);
			}
		}
	}

	public void report() {
		if (department.isEmpty())
			System.out.println("There are no departments!");
		else {
			System.out.printf("%-30s%-20s", "Department Name", "Number of employees");
			System.out.println("");
			for (Department d : department) {
				d.display();
				System.out.println("");
			}
		}
	}

	public void addDepartment() {
		System.out.print("Enter department name: ");
		String name = Validator.checkInputString();
		while (checkDepartment(name) != -1) {
			System.err.println("Department name is already existed!");
			System.out.print("Enter again: ");
			name = Validator.checkInputString();
		}
		Department d = new Department(name, null);
		department.add(d);
		System.out.println("New department added!");
	}

	public void save() {
		File file = new File("EmployeeManagement.dat");
		FileWriter fw = null;
		try {
			fw = new FileWriter(file);
			fw.write("Employees:\n");
			for (Employee e : employee) {
				String data = e.toString();
				fw.write(data + "\n");
			}
			fw.write("\nDepartments:\n");
			for (Department d : department) {
				String data = d.toString();
				fw.write(data + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Data is saved!!");
	}
}
