/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Validator {
	public static final String EMAIL_PATTERN = "(\\w+)@(\\w+).(com|net)";
	public static final String PHONE_PATTERN = "\\d{7}";
	public static final String DATE_PATTERN = "dd/MM/yyyy";
	
	
	public static Scanner in = new Scanner(System.in);

	public static String checkInputString() {
		in.nextLine();
		String result = in.next().trim();
		if (result.isEmpty()) {
			System.out.println("String can't be empty!");
			System.out.println("Please enter again!\n");
			return checkInputString();
		} else {
			return result;
		}
	}

	public static int checkInputInt() {
		int result;
		while (true) {
			result = in.nextInt();
			if (result < 0) {
				System.out.println("Can't input negative number!");
				System.out.println("Please input again.");
			} else {
				return result;
			}
		}
	}

	public static double checkInputDouble() {
		double result;
		while (true) {
			result = in.nextDouble();
			if (result < 0) {
				System.out.println("Can't input negative number!");
				System.out.println("Please input again.");
			} else {
				return result;
			}
		}
	}

	public static int checkInputLimit(int min, int max) {
		int result;
		while (true) {
			result = checkInputInt();
			if (result >= min || result <= max) {
				return result;
			} else {
				System.err.println("Please input number in range [" + min + ", " + max + "]");
				System.out.println("Please enter again: ");
			}
		}
	}

	public static double checkInputPoint(int min, int max) {
		double result;
		while (true) {
			result = checkInputDouble();
			if (result >= min || result <= max) {
				return result;
			} else {
				System.err.println("Please input number in range [" + min + ", " + max + "]");
				System.out.println("Please enter again: ");
			}
		}
	}

	public static String checkMail() {
		String mail;
		String email = EMAIL_PATTERN;
		do {
			mail = in.next();
		} while (!mail.matches(email));
		return mail;
	}

	public static String checkPhone() {
		String number;
		String phonepat = PHONE_PATTERN;
		do {
			number = in.next();
		} while (!number.matches(phonepat));
		return number;
	}

	public static boolean checkInputYN() {
		while (true) {
			String result = in.next();
			if (result.equalsIgnoreCase("Y")) {
				return true;
			} else if (result.equalsIgnoreCase("N")) {
				return false;
			}
			System.err.println("Please input Y or N!");
			System.out.println("Enter again: ");
		}
	}

	public static Date checkInputDate() {
        DateFormat ft = new SimpleDateFormat (DATE_PATTERN);
        ft.setLenient(false);
        while (true) {
            try {
                Date result = ft.parse(in.nextLine().trim());
                return result;
            } catch (ParseException e) {
                System.err.println("Inputted string must be a date (dd/MM/yyyy)! Error: "+e);
                System.out.print("Enter again: ");
            }
        }
    }
	
	public static double checkInputLimitDouble(double min, double max){
        while(true){
            double result = checkInputDouble();
            if (result >= min && result <= max) return result;
            else{
                System.err.println("Rate is from "+min+" to "+max+"!");
                System.out.print("Enter again: ");
            }
        }
    }
	
	public static double checkInputPositive(){
        while(true){
            double result = checkInputDouble();
            if (result > 0) return result;
            else{
                System.err.println("Please input a number > 0!");
                System.out.print("Enter again: ");
            }
        }
    }

}
