/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 4 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.services.DepartmentService;
import training.entities.Department;
import training.utils.Validator;

public class DepartmentManagement {

	private static void Menu() {
		System.out.println("-------Menu-------");
		System.out.println("\n1. Create & save department." 
						 + "\n2. Show all info." 
						 + "\n3. Remove a department."
						 + "\n4. Exit." 
						 + "\nYour choice: ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DepartmentService departmentService = new DepartmentService();
		Scanner in = new Scanner(System.in);
		int option = 0;
		do {
			Menu();
			option = Integer.parseInt(in.nextLine());
			switch (option) {
			case 1:
				try {
					List<String> listDepartment = createDepartment(in);
					departmentService.save(listDepartment, true);
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					List<String> listDepartment = departmentService.findAll();
					display(listDepartment);
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter department ID: ");
				String deptId = in.nextLine();
				try {
					System.out.println("Removed: "+ departmentService.remove(deptId));
				} catch (Exception e) {
					// TODO: handle exception
				}

				break;
			}
		} while (option<4);
		in.close();
	}
	
	private static List<String> createDepartment(Scanner in) {
		List<String> departments = new ArrayList<>();
		char loop;
		Department department = null;
		boolean invalid;
		
		do {
			String deptNo = null;
			
			do {
				invalid = false;
				System.out.println("Enter department number ( Start with 'DP' + 3 digits): ");
				deptNo = in.nextLine();
				if (!Validator.checkInputDeptId(deptNo)) {
					invalid = true;
				}
			} while (invalid);
			
			System.out.println("Enter Department name: ");
			String deptName = in.nextLine();
			System.out.println("Enter Department location: ");
			String location = in.nextLine();
			
			department = new Department(deptNo, deptName, location);
			departments.add(department.toString());
			
			System.out.println("Do you want continue (Y/N)? : ");
			loop = in.nextLine().charAt(0);
			
		} while ((loop == 'Y') || (loop == 'y'));
		return departments;
	}
	
	public static void display(List<String> listDepartment) {
		if (listDepartment != null) {
			for (String department : listDepartment) {
				System.out.println(department);
			}
		} else {
			System.out.println("No data");
		}
	}

}
