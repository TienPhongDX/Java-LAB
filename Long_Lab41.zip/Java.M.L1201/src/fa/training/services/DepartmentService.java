/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 4 thg 2, 2021
 * Version: 1.0
 *
 */

package fa.training.services;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import training.utils.Constant;
import training.utils.Validator;

public class DepartmentService {

	public String save(List<String> listDepartment, boolean append) throws Exception {
		try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(Constant.FILE_PATH, append));) {
			for (String department : listDepartment) {
				bufferedWriter.write(department + "\n");
			}
			bufferedWriter.flush();
		} catch (Exception e) {
			// TODO: handle exception
			throw new IOException();
		}

		return Constant.SUCCESS;
	}

	public List<String> findAll() throws Exception {
		File f = new File(Constant.FILE_PATH);
		List<String> listDepartmentInfo = new ArrayList<>();

		if (!f.exists() && !f.canRead()) {
			return null;
		}
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(Constant.FILE_PATH));) {
			while (bufferedReader.read() != -1) {
				listDepartmentInfo.add(bufferedReader.readLine());
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new IOException();
		}
		return listDepartmentInfo;
	}
	
	public String remove(String id) throws Exception {
		List<String> deStrings = findAll();
		
		if (deStrings != null && Validator.checkInputDeptId(id)) {
			Iterator<String> iterator = deStrings.iterator();
			boolean removed = false;
			while (iterator.hasNext()) {
				String department = (String) iterator.next();
				if (department.contains("deptNo="+id)) {
					iterator.remove();
					removed = true;
					break;
				}
			}
			if (removed) {
				save(deStrings, false);
				return Constant.SUCCESS;
			}
			return Constant.FAIL;
		}
		
		return Constant.FAIL;
	}
}
