/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 4 thg 2, 2021
 * Version: 1.0
 *
 */

package training.entities;

public class Department {
	private static final long serialVersionUID = 1L;
	private String deptNo;
	private String deptName;
	private String location;
	
	public Department() {
		// TODO Auto-generated constructor stub
	}

	public Department(String deptNo, String deptName, String location) {
		super();
		this.deptNo = deptNo;
		this.deptName = deptName;
		this.location = location;
	}

	public String getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Department [deptNo=" + deptNo + ", deptName=" + deptName + ", location=" + location + "]";
	}
	
	
}
