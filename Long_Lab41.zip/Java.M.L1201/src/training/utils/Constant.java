/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 4 thg 2, 2021
 * Version: 1.0
 *
 */

package training.utils;

public class Constant {
	public static final String FILE_PATH = "department.dat";
	public static final String SUCCESS = "success";
	public static final String FAIL = "fail";
	public static final String EMPTY = "File is empty";
}
