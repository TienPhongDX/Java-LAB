/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 4 thg 2, 2021
 * Version: 1.0
 *
 */

package training.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
	private static final String DEPT_ID_REGEX = "^[DP]+\\d{3,3}";
	
	public static boolean checkInputDeptId(String deptId) {
		Pattern pattern = Pattern.compile(DEPT_ID_REGEX);
		Matcher matcher = pattern.matcher(deptId);
		return matcher.matches();
	}
}
