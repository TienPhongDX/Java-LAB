/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

public class Complex {
	private double realPart;
	private double imaginaryPart;

	public Complex() {
		super();
		this.realPart = 0.0;
		this.imaginaryPart = 0.0;
		System.out.println("Complex without parameter!");
	}

	public Complex(double realPart, double imaginaryPart) {
		super();
		this.realPart = realPart;
		this.imaginaryPart = imaginaryPart;
		System.out.println("Complex with 2 parameter!");
	}

	public double getRealPart() {
		return realPart;
	}

	public void setRealPart(double realPart) {
		this.realPart = realPart;
	}

	public double getImaginaryPart() {
		return imaginaryPart;
	}

	public void setImaginaryPart(double imaginaryPart) {
		this.imaginaryPart = imaginaryPart;
	}

	public Complex add(Complex otherNum) {
		double resultRealPart = this.realPart + otherNum.realPart;
		double resultImaginaryPart = this.imaginaryPart + otherNum.imaginaryPart;
		
		Complex resultNum = new Complex(resultRealPart, resultImaginaryPart);
		return resultNum;

	}

	@Override
	public String toString() {
		return "Complex [realPart=" + realPart + ", imaginaryPart=" + imaginaryPart + "]";
	}

}
