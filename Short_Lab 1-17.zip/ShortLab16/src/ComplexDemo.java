/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

public class ComplexDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Complex currentNum = new Complex(1000, 1200);
		Complex otherNum = new Complex(600, 800);
		
		Complex resultNum = currentNum.add(otherNum);
		System.out.println(resultNum);
	}

}
