/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 18 thg 1, 2021
 * Version: 1.0
 *
 */

package ShortLab6;

import java.util.Scanner;

public class CheckOddEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter value for number: ");
		int num = in.nextInt();
		System.out.println("The number is " + num );
		if (num%2==0) {
			System.out.println("Even number");
		} else {
			System.out.println("Odd number");
		}
		System.out.println("------------");
		System.out.println("Bye");
	}

}
