/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 18 thg 1, 2021
 * Version: 1.0
 *
 */

package ShortLab3;

import java.util.Scanner;

public class SwapNumber {
	public static void main(String[] args) {
		SwapNumber swapNumbers = new SwapNumber();
		Scanner in = new Scanner(System.in);

		System.out.println("Input number 1: ");
		int num1 = Integer.parseInt(in.nextLine());
		System.out.println("Input number 2: ");
		int num2 = Integer.parseInt(in.nextLine());
		System.out.println("Before swap: num1 = " + num1 + " , num2 = " + num2);
		swapNumbers.swap(num1, num2);
		System.out.println("After swap: num1 = " + num1 + " , num2 = " + num2);
	}

	public void swap(int num1, int num2) {
		int temp = num1;
		num1 = num2;
		num2 = temp;
		System.out.println("In swap: num1 = " + num1 + " , num2 = " + num2);
	}
}
