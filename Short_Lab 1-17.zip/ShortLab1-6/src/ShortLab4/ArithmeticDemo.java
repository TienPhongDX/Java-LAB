/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 18 thg 1, 2021
 * Version: 1.0
 *
 */

package ShortLab4;

public class ArithmeticDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int result = 1 + 2;
		System.out.println("1 + 2 = " + result);
		int original_result = result;
		String firstString = "This is";
		String secondString = " a concatenated string.";
		String thirdString = firstString + secondString;
		System.out.println(thirdString);

		result = result - 1;
		System.out.println(original_result + " - 1 = " + result);
		original_result = result;
		
		result = result * 2;
		System.out.println(original_result + " * 2 = " + result);
		original_result = result;

		result = result / 2;
		System.out.println(original_result + " / 2 = " + result);
		original_result = result;
		
		result = result % 7;
		System.out.println(original_result + " % 7 = " + result);
		original_result = result;

	}

}
