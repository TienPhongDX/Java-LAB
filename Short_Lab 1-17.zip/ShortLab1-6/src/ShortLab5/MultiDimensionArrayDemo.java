/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 18 thg 1, 2021
 * Version: 1.0
 *
 */

package ShortLab5;

public class MultiDimensionArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] matrix = new int[2][2];
		matrix[0][0] = 1; // row: 1 | collumn: 1
		matrix[0][1] = 2; // row: 1 | collumn: 2
		matrix[1][0] = 3; // row: 2 | collumn: 1
		matrix[1][1] = 4; // row: 2 | collumn: 2
		System.out.println("Element at second rows and first collumn is: "+matrix[1][0]);
		System.out.println("Number of rows: " + matrix.length);
		System.out.println("Number of collumn: "+matrix[0].length);
	}

}
