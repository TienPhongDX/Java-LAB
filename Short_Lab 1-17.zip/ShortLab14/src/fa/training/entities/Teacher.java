/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public abstract class Teacher implements Actionable{
	private String designation;
	private String collegeName;

	public Teacher() {
		super();
	}

	public Teacher(String designation, String collegeName) {
		super();
		this.designation = designation;
		this.collegeName = collegeName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	
	public abstract void teach();
	
	public void teach(int duration) {
		System.out.println("Teaching in "+duration+" minutes");
	}

	@Override
	public String toString() {
		return ", designation = " + designation + ", collegeName = " + collegeName+" ]";
	}
	
	
}
