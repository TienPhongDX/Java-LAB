/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public interface Actionable {
	void toSchool();
}
