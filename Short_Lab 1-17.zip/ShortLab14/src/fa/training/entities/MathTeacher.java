/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public class MathTeacher extends Teacher{
	private String mainSubject;

	public MathTeacher() {
		super();
	}

	public MathTeacher(String designation, String collegeName, String mainSubject) {
		super(designation, collegeName);
		this.mainSubject = mainSubject;
	}

	public String getMainSubject() {
		return mainSubject;
	}

	public void setMainSubject(String mainSubject) {
		this.mainSubject = mainSubject;
	}
	
	public int sum(int num1, int num2) {
		return (num1+num2);
	}

	@Override
	public String toString() {
		return "MathTeacher [Main subject = " + mainSubject + ", Designation = " + getDesignation()
				+ ", College name = " + getCollegeName() + "]";
	}

	@Override
	public void toSchool() {
		// TODO Auto-generated method stub
		System.out.println("Math teacher go to school by car!");
	}

	@Override
	public void teach() {
		// TODO Auto-generated method stub
		System.out.print("Teaching Math subject: ");
	}
	
	
	
}
