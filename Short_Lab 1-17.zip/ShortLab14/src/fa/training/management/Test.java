/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.management;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
