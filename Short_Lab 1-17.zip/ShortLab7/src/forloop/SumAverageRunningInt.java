/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package forloop;

public class SumAverageRunningInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		double avg = 0.0;
		int lowerBound = 1;
		int upperBound = 100;

		for (int i = lowerBound; i <= upperBound; i++) {
			sum += i;
		}
		avg = sum / upperBound;
		System.out.println("Average of 100 first number: " + avg);

	}

}
