/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package forloop;

public class AverageArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = { 12, 5, 9, 8, 11, 86 };
		int sum = 0;
		double avg = 0.0;
		for (int i = 0; i < array.length; i++) {
			sum += array[i];
		}
		avg = sum / array.length;
		System.out.println("Average of all element in Array: "+avg);
	}

}
