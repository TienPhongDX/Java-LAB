/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package forloop;

public class HarmonicSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HarmonicSum hmSum = new HarmonicSum();
		int n = 50000;
		double l2rSum = hmSum.printLeftToRightSum(n);
		double r2lSum = hmSum.printRightToLeftSum(n);
		System.out.printf("Difference: %.15f", (l2rSum - r2lSum));
	}

	public double printLeftToRightSum(int n) {
		double sum = 0.0;
		for (int i = 1; i <= n; i++) {
			sum += (double) 1 / i;
		}
		System.out.println("Left to right harmonic sum: " + sum);
		return sum;
	}

	public double printRightToLeftSum(int n) {
		double sum = 0.0;
		for (int i = n; i >= 1; i--) {
			sum += (double) 1 / i;
		}
		System.out.println("Right to left harmonic sum: " + sum);
		return sum;
	}
}
