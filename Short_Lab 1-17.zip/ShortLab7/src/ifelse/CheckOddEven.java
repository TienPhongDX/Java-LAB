/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package ifelse;

import java.util.Scanner;

public class CheckOddEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);

		System.out.print("Enter value for number: ");
		int number = in.nextInt();
		System.out.println("The number is " + number);
		if (number%2==0) {
			System.out.println("Even number");
		} else {
			System.out.println("Odd number");
		}
		System.out.println("----------");
		System.out.println("Bye");
	}

}
