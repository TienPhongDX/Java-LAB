/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package ifelse;

import java.util.Scanner;

public class CheckPassFail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);

		System.out.print("Enter value for number: ");
		int mark = in.nextInt();
		System.out.println("The mark is " + mark);
		if (mark >= 50) {
			System.out.println("PASS");
		} else {
			System.out.println("NOT PASS");
		}
		System.out.println("----------");
		System.out.println("CHECK DONE");
	}

}
