/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package whileloop;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 1;
		int nMax = 20;
		int fn1 = 1;
		int fn2 = 1;
		int sum = fn1 + fn2;
		double avg;
		System.out.println("The first " + nMax + " Fibonacci numbers are: ");
		while(n<=nMax) {
			System.out.print(fn1 + " ");
			sum = fn1+fn2;
			fn1 = fn2;
			fn2 = sum;
			++n;
		}
		avg = sum/nMax;
		System.out.println("\nThe average is "+avg);
	}

}
