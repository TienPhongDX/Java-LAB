/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.util.Scanner;

public class Student {
	Scanner in = new Scanner(System.in);
	
	private int id;
	private String name;
	private byte age;
	private double gpa;
	
	
	public Student() {
		super();
	}
	
	public Student(int id, String name, byte age, double gpa) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gpa = gpa;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public byte getAge() {
		return age;
	}
	public void setAge(byte age) {
		this.age = age;
	}
	public double getGpa() {
		return gpa;
	}
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", gpa=" + gpa + "]";
	}
	
	public void input() {
		System.out.print("Enter ID: ");
		id = in.nextInt();
		System.out.print("Enter name: ");
		name = in.nextLine();
		System.out.print("Enter age: ");
		age = in.nextByte();
		System.out.print("Enter gpa: ");
		gpa = in.nextDouble();
	}
	
}
