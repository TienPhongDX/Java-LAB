/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.test;

import fa.training.entities.Student;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student st1 = new Student(1, "Jason", (byte) 22, 8.0);
		Student st2 = new Student();
		System.out.println("Enter student 2 information: ");
		st2.input();
		System.out.println("--STUDENT LIST--");
		System.out.println(st1);
		System.out.println(st2);
	}

}
