/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.test;

import fa.training.entities.Employee;

public class Test {
	public static void main(String[] args) {
		Employee[] emp = new Employee[5];
		System.out.println("1. Enter employee: ");
		for (int i = 0; i < emp.length; i++) {
			System.out.println("- Enter employee["+(i+1)+"]: ");
			emp[i] = new Employee();
			emp[i].input();
			
		}
		System.out.println("2. Display employee's salary >= 1000: ");
		for (int i = 0; i < emp.length; i++) {
			if (emp[i].getSalary()>=1000) {
				System.out.println(emp[i]);
			}
		}
	}
}
