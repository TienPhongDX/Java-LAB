/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import java.util.Scanner;

import fa.training.utils.Validator;

public class Employee {
	private int id;
	private String employeeName;
	private byte gender;
	private String email;
	private String address;
	private double salary;

	public Employee() {

	}

	public Employee(int id, String employeeName, byte gender, String email, String address, double salary) {
		super();
		this.id = id;
		this.employeeName = employeeName;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public byte getGender() {
		return gender;
	}

	public void setGender(byte gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void input() {
		Scanner in = new Scanner(System.in);
		boolean status;

		//Input ID
		do {
			status = false;
			System.out.print("Enter id (number): ");
			try {
				id = Integer.parseInt(in.nextLine());
			} catch (Exception e) {
				// TODO: handle exception
				System.err.println("Wrong ID!! Please input again");
				status = true;
			}
		} while (status);

		//Input name
		System.out.print("Enter name: ");
		employeeName = in.nextLine();

		//Input gender
		do {
			status = false;
			System.out.print("Enter gender (1: male; 0: female):");
			try {
				gender = Byte.parseByte(in.nextLine());
				status = !(Validator.isGender(gender));
			} catch (Exception e) {
				// TODO: handle exception
				System.err.println("Wrong Gender!! Please input again");
				status = true;
			}
		} while (status);

		//Input Email
		do {
			status = false;
			System.out.print("Enter email (follow email format): ");
			try {
				email = in.nextLine();
				status = !(Validator.isEmail(email));
			} catch (Exception e) {
				// TODO: handle exception
				System.err.println("Wrong email format!! Please input again");
				status = true;
			}
		} while (status);
		
		//Input address
		System.out.print("Enter address: ");
		address = in.nextLine();
		
		//Input salary
		System.out.print("Enter salary:");
		salary = in.nextDouble();

	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", employeeName=" + employeeName + ", gender=" + gender + ", email=" + email
				+ ", address=" + address + ", salary=" + salary + "]";
	}

}
