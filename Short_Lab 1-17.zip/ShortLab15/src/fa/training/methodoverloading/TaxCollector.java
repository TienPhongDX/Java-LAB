/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.methodoverloading;

public class TaxCollector {
	public static void main(String[] args) {
		BasicRateTax brTax = new BasicRateTax();
		double grossIncome = Double.parseDouble(args[0]);
		System.out.println("Tax due is " + brTax.calcTax(grossIncome));

	}
}
