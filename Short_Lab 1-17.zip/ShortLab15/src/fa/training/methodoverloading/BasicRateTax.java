/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.methodoverloading;

public class BasicRateTax {
	public static final double BASIC_INCOME = 1000;
	public static final double BASIC_TAX_RATE = 0.2;
	
	public double calcTax() {
		return BASIC_INCOME * BASIC_TAX_RATE;
	}

	public double calcTax(double grossIncome) {
		if (grossIncome < BASIC_INCOME) return calcTax();
		return grossIncome * BASIC_TAX_RATE;

	}
}
