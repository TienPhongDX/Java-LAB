/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator cal =new Calculator();
		int num1 = 20, num2 = 2;
		System.out.println("Sum: "+cal.sum(num1, num2));
		System.out.println("Subtract: "+cal.sub(num1, num2));
		System.out.println("Multiple: "+cal.mul(num1, num2));
		System.out.println("Divise: "+cal.div(num1, num2));
	}

}
