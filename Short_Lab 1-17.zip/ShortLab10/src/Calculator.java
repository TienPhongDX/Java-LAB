/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

public class Calculator {

	public int sum(int num1, int num2) {
		return (num1+num2);
	}
	public int sub(int num1, int num2) {
		return (num1-num2);
	}
	public int mul(int num1, int num2) {
		return (num1*num2);
	}
	public int div(int num1, int num2) {
		return (num1/num2);
	}
}
