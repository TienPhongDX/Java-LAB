/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.abstraction;

import java.util.Scanner;

public abstract class Employee {
	private String empName;
	private String DoB;
	private String Address;
	private static String compName;
	
	
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDoB() {
		return DoB;
	}

	public void setDoB(String doB) {
		DoB = doB;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public static String getCompName() {
		return compName;
	}

	public static void setCompName(String compName) {
		Employee.compName = compName;
	}

	public abstract double calcSalary();
	
	protected void inputData(Scanner in) {
		System.out.print("Enter Employee name: ");
		empName = in.nextLine();
		System.out.print("Enter birth date: ");
		DoB = in.nextLine();
		System.out.print("Enter address: ");
		Address = in.nextLine();
	}
	protected void display() {
		System.out.println(empName+"\t"+DoB+"\t"+Address+"\t"+compName);
	}
}
