/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.abstraction;

import java.util.Scanner;

public class DailyStaff extends Employee{

	private static final int WAGE_DAY = 15;
	private double numberOfWorkDay;
	
	@Override
	public double calcSalary() {
		// TODO Auto-generated method stub
		return numberOfWorkDay*WAGE_DAY;
	}

	@Override
	protected void inputData(Scanner in) {
		// TODO Auto-generated method stub
		super.inputData(in);
		System.out.println("Enter number of workday: ");
		numberOfWorkDay = Double.parseDouble(in.nextLine());
		
		System.out.println("-----------------------------");
	}

	@Override
	protected void display() {
		// TODO Auto-generated method stub
		super.display();
		System.out.print("\t"+numberOfWorkDay+"\t"+this.calcSalary()+"\n");
	}
	
}
