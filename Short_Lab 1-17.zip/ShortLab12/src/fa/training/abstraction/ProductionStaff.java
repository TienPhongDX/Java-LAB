/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.abstraction;

import java.util.Scanner;

public class ProductionStaff extends Employee{
	
	private static final int UNIT_PRICE = 20;
	private double amountOfProduct;
	
	@Override
	public double calcSalary() {
		// TODO Auto-generated method stub
		return amountOfProduct*UNIT_PRICE;
	}

	@Override
	protected void inputData(Scanner in) {
		// TODO Auto-generated method stub
		super.inputData(in);
		System.out.println("Enter amount of product: ");
		amountOfProduct = Double.parseDouble(in.nextLine());
		System.out.println("-----------------------------");
	}

	@Override
	protected void display() {
		// TODO Auto-generated method stub
		super.display();
		System.out.print("\t"+amountOfProduct+"\t"+this.calcSalary()+"\n");
	}
	
	

}
