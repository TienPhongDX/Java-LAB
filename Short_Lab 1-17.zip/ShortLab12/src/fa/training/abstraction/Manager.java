/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.abstraction;

import java.util.Scanner;

public class Manager extends Employee {

	private double wage;
	private double basicSalary;
	
	@Override
	public double calcSalary() {
		// TODO Auto-generated method stub
		return wage*basicSalary;
	}

	@Override
	protected void inputData(Scanner in) {
		// TODO Auto-generated method stub
		super.inputData(in);
		System.out.println("Enter wage: ");
		wage = Double.parseDouble(in.nextLine());
		System.out.println("Enter basic salary: ");
		basicSalary = Double.parseDouble(in.nextLine());
		System.out.println("-------------------------");
	}

	@Override
	protected void display() {
		// TODO Auto-generated method stub
		super.display();
		System.out.println("\t"+wage+"\t"+basicSalary+"\t"+this.calcSalary()+"\n");
	}
	
}
