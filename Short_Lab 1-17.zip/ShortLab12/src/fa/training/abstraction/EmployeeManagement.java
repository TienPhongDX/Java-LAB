/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 19 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.abstraction;

import java.util.Iterator;
import java.util.Scanner;

public class EmployeeManagement {
	public static void main(String[] args) {
		Employee[] emp = new Employee[3];
		
		ProductionStaff proStaff = new ProductionStaff();
		DailyStaff daiStaff = new DailyStaff();
		Manager manager = new Manager();
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Employee 1: ");
		proStaff.inputData(in);
		
		System.out.println("Employee 2: ");
		daiStaff.inputData(in);
		
		System.out.println("Employee 3: ");
		manager.inputData(in);
		
		Employee.setCompName("FPT");
		
		emp[0] = proStaff;
		emp[1] = daiStaff;
		emp[2] = manager;
		
		for(Employee e:emp) {
			e.display();
		}
		in.close();
	}
}
