/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.management;

import fa.training.entities.MathTeacher;

public class TeacherManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MathTeacher mathTeacher = new MathTeacher("Teacher", "FU", "Math");
		System.out.println(mathTeacher);
		
		mathTeacher.teach();
		System.out.print("20 + 80 = " + mathTeacher.sum(20, 80));
		
	}

}
