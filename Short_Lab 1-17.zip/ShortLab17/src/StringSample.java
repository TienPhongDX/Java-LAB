/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 20 thg 1, 2021
 * Version: 1.0
 *
 */

public class StringSample {

	public static void main(String[] args) {
		
////////-- String Immutable: always create new objects when changing --
		
		System.out.println("-- String Immutable: always create new objects when changing --");
		String value = "fpt";
		System.out.println("Before change: " + value);
		value = value.concat(" Software");
		value = value.toUpperCase();
		System.out.println("After change: " + value);

////////-- String Literal: the same reference to only one value in the string pool --
		
		System.out.println("-- String Literal: the same reference to only one value in the string pool --");

		String firstString = "VietNam";
		String secondString = "VietNam";
		String thirdString = "Japan";

		System.out.println("First string == Second string: " + (firstString == secondString));
		System.out.println("First string == Third string: " + (firstString == thirdString));

////////-- String Object: the difference reference in heap space --
		
		System.out.println("-- String Object: the difference reference in heap space --");
		String fourthString = new String("VietNam");
		String fifthString = new String("VietNam");
		String sixthString = new String("Japan");
		
		System.out.println("Fourth string == Fifth string: " + (fourthString == fifthString));
		System.out.println("Fourth string == Sixth string: " + (fourthString == sixthString));

////////-- String Method --
		
		System.out.println("-- String Method --");
		String str = "FPT Software";
		System.out.println("concat() method: "+ str.concat(" VietNam"));
		System.out.println("toUpperCase() method: "+str.toUpperCase());
		System.out.println("toLowerCase() method: "+str.toLowerCase());
		System.out.println("substring() method: "+str.substring(0, 4));
		System.out.println("length() method: "+str.length());
		System.out.println("indexOf() method: "+str.indexOf("t"));
		System.out.println("lastIndexOf() method: "+str.lastIndexOf("t"));
		System.out.println("charAt() method: "+str.charAt(8));
		System.out.println("contains() method: "+ str.contains("ware"));
		String s1 = "FPT";
		String s2 = new String("FPT");
		System.out.println("s1 == s2: "+(s1==s2));
		System.out.println("s1.equals(s2): " + s1.equals(s2));
	}

}
