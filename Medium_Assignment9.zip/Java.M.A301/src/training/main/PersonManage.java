/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 21 thg 1, 2021
 * Version: 1.0
 *
 */
package training.main;

import java.util.ArrayList;
import java.util.Scanner;
import training.entities.Person;
import training.entities.Student;
import training.entities.Teacher;
import training.utils.Validator;


public class PersonManage {

    public static Scanner s1 = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Person> ls = new ArrayList<>();

        Student s = new Student();
        Teacher t = new Teacher();
        s.ls.add(new Student("DE01", 7, 8.5, "Tien Phong", "Male", "0944577519", "phong@gmail.com"));
        s.ls.add(new Student("DE02", 6.5, 9, "Nhat Hoang", "FeMale", "0898223845", "hoang@gmail.com"));
        t.ls.add(new Teacher(8500, 50, "Trung Quan", "Male", "0956182746", "chuchotaiba@gmail.com"));
        t.ls.add(new Teacher(5500, 150, "Phung Hien", "Male", "0917552461", "hiendx@gmail.com"));

        int choice;
        do {
            System.out.println("==================Person Manager==================");
            System.out.println("      1. Add a Student");
            System.out.println("      2. Add a Teacher");
            System.out.println("      3. Update student");
            System.out.println("      4. Display high salary teacher (>1000$)");
            System.out.println("      5. Display passed students ");
            System.out.println("      6. Exit");
            System.out.println("==================================================");
            System.out.print("Enter your choice --> ");
            choice = Validator.checkinputLimit(1, 6);
            switch (choice) {
                case 1:
                    s.inputStudent();
                    break;
                case 2:
                    t.inputTeacher();
                    break;
                case 3:
                    s.updateStudent();
                    break;
                case 4:
                    System.out.println("High salary teacher: ");
                    t.display();
                    break;
                case 5:
                    System.out.println("Passed Student: ");
                    s.display();
                    break;
                case 6:
                    return;
            }
        } while (choice > 0 && choice < 6);
    }

}
