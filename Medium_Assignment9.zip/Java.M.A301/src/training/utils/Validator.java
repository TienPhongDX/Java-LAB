/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 21 thg 1, 2021
 * Version: 1.0
 *
 */
package training.utils;

import java.util.ArrayList;
import java.util.Scanner;
import training.entities.Student;

public class Validator {

    public static Scanner k = new Scanner(System.in);

    public static String checkinputString() {
        k.nextLine();
        String result = k.nextLine().trim();
        if (result.isEmpty()) {
            System.out.println("String can't be empty!");
            System.out.println("Please enter again!\n");
            return checkinputString();
        } else {
            return result;
        }
    }

    public static int checkinputInt() {
        int result;
        while (true) {
            result = k.nextInt();
            if (result < 0) {
                System.out.println("Can't input negative number!");
                System.out.println("Please input again.");
            } else {
                return result;
            }
        }
    }

    public static double checkinputDouble() {
        double result;
        while (true) {
            result = k.nextDouble();
            if (result < 0) {
                System.out.println("Can't input negative number!");
                System.out.println("Please input again.");
            } else {
                return result;
            }
        }
    }

    public static int checkinputLimit(int min, int max) {
        int result;
        while (true) {
            result = checkinputInt();
            if (result >= min || result <= max) {
                return result;
            } else {
                System.err.println("Please input number in range [" + min + ", " + max + "]");
                System.out.print("Please enter again: ");
            }
        }
    }

    public static double checkinputPoint(int min, int max) {
        double result;
        while (true) {
            result = checkinputDouble();
            if (result >= min || result <= max) {
                return result;
            } else {
                System.err.println("Please input number in range [" + min + ", " + max + "]");
                System.out.print("Please enter again: ");
            }
        }
    }

    public static String checkMail() {
        String mail;
        String email = "(\\w+)@(\\w+).(com|net)";
        do {
            mail = k.next();
        } while (!mail.matches(email));
        return mail;
    }

    public static String checkPhone() {
        String number;
        String phonepat = "\\d{10}";
        do {
            number = k.next();
        } while (!number.matches(phonepat));
        return number;
    }

    public static boolean checkinputYN() {
        while (true) {
            String result = k.next();
            if (result.equalsIgnoreCase("Y")) {
                return true;
            } else if (result.equalsIgnoreCase("N")) {
                return false;
            }
            System.err.println("Please input Y or N!");
            System.out.print("Enter again: ");
        }
    }

    public static int checkIdExit(ArrayList<Student> ls, String id) {
        for (int i = 0; i < ls.size(); i++) {
            if (ls.get(i).getStudentId().equalsIgnoreCase(id)) {
                return i;
            }
        }
        return -1;
    }
}
