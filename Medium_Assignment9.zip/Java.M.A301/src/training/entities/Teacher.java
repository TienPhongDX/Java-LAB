/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 21 thg 1, 2021
 * Version: 1.0
 *
 */
package training.entities;

import java.util.ArrayList;
import training.utils.Validator;

public class Teacher extends Person {

    public ArrayList<Teacher> ls = new ArrayList<>();

    private double basicSalary;
    private double subsidy;

    public Teacher() {
    }

    public Teacher(double basicSalary, double subsidy) {
        this.basicSalary = basicSalary;
        this.subsidy = subsidy;
    }

    public Teacher(double basicSalary, double subsidy, String fullName, String gender, String phone, String email) {
        super(fullName, gender, phone, email);
        this.basicSalary = basicSalary;
        this.subsidy = subsidy;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(double subsidy) {
        this.subsidy = subsidy;
    }

    public void inputTeacher() {
        System.out.print("Enter basic salary: ");
        double basicSalary1 = Validator.checkinputDouble();
        System.out.print("Enter subsidy: ");
        double subsidy1 = Validator.checkinputDouble();
        System.out.print("Enter full name: ");
        String fullName = Validator.checkinputString();
        System.out.print("Enter Gender: ");
        String gender = Validator.k.next();
        System.out.print("Enter phone number: ");
        String phone = Validator.checkPhone();
        System.out.print("Enter Email: ");
        String email = Validator.checkMail();
        ls.add(new Teacher(basicSalary1, subsidy1, fullName, gender, phone, email));
        System.out.println("Do you want to add more?(Y or N)");
        if (Validator.checkinputYN()) {
            inputTeacher();
        } else {
            System.out.println("Added Teacher Succesfully!");
        }
    }

    public double calculateSalary() {
        double result = basicSalary + subsidy;
        return result;
    }

    @Override
    public String toString() {
        return "Teacher{" + super.toString() + ", basicSalary= " + basicSalary
                + ", subsidy= " + subsidy + ", total salary= " + calculateSalary() + '}';
    }

    public void display() {
        ls.stream().filter((selectedItem) -> (selectedItem.calculateSalary() >= 1000)).forEachOrdered((selectedItem) -> {
            System.out.println(selectedItem);
        });
    }

	@Override
	void purchaseParkingPass() {
		// TODO Auto-generated method stub
		
	}
}
