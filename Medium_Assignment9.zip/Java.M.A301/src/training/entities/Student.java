/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 21 thg 1, 2021
 * Version: 1.0
 *
 */
package training.entities;

import java.util.ArrayList;
import java.util.Scanner;
import training.utils.Validator;

public class Student extends Person {

    public ArrayList<Student> ls = new ArrayList<>();
    public ArrayList<Person> list = new ArrayList<>();
    public Scanner in = new Scanner(System.in);

    private String studentId;
    private double theory;
    private double practice;

    public Student() {
    }

    public Student(String studentId, double theory, double practice) {
        this.studentId = studentId;
        this.theory = theory;
        this.practice = practice;
    }

    public Student(String studentId, double theory, double practice, String fullName, String gender, String phone, String email) {
        super(fullName, gender, phone, email);
        this.studentId = studentId;
        this.theory = theory;
        this.practice = practice;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public double getTheory() {
        return theory;
    }

    public void setTheory(double theory) {
        this.theory = theory;
    }

    public double getPractice() {
        return practice;
    }

    public void setPractice(double practice) {
        this.practice = practice;
    }

    public void inputStudent() {
        System.out.print("Enter Student ID: ");
        String studentId1 = Validator.checkinputString();
        System.out.print("Enter Theory point: ");
        double theory1 = Validator.checkinputPoint(0, 10);
        System.out.print("Enter Practice point: ");
        double practice1 = Validator.checkinputPoint(0, 10);
        System.out.print("Enter full name: ");
        String fullName = Validator.checkinputString();
        System.out.print("Enter Gender: ");
        String gender = in.next();
        System.out.print("Enter phone number: ");
        String phone = Validator.checkPhone();
        System.out.print("Enter Email: ");
        String email = Validator.checkMail();
        ls.add(new Student(studentId1, theory1, practice1, fullName, gender, phone, email));
        System.out.println("Do you want to add more?");
        if (Validator.checkinputYN()) {
            inputStudent();
        } else {
            System.out.println("Added Student Succesfully!");
        }
    }

    public void updateStudent() {
        System.out.print("Enter Student ID: ");
        String Id = in.nextLine();
        int count = 0;
        for (int i = 0; i < ls.size(); i++) {
            if (ls.get(i).getStudentId().equalsIgnoreCase(Id)) {
                System.out.println("Found the item. Do you want to update? Y/N");
                Boolean check = Validator.checkinputYN();
                if (check) {
                    System.out.print("Enter Theory point: ");
                    double theory1 = Validator.checkinputPoint(0, 10);
                    System.out.print("Enter Practice point: ");
                    double practice1 = Validator.checkinputPoint(0, 10);
                    System.out.print("Enter full name: ");
                    String fullName = Validator.checkinputString();
                    System.out.print("Enter Gender: ");
                    String gender = in.next();
                    System.out.print("Enter phone number: ");
                    String phone = Validator.checkPhone();
                    System.out.print("Enter Email: ");
                    String email = Validator.checkMail();
                    ls.set(i, new Student(Id, theory1, practice1, fullName, gender, phone, email));
                    System.out.println("Update Successfully!");
                } else {
                    System.err.println("Student not updated!");
                }
            } else {
                count++;
                if (count == ls.size()) {
                    System.out.println("Student not found!");
                }
            }
        }
    }

    @Override
    void purchaseParkingPass() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public double calculateFinalMark() {
        double result = (theory + practice) / 2;
        return result;
    }

    @Override
    public String toString() {
        return "Student{" + " Student ID: " + studentId + super.toString() + ", Theory: " + theory + ", Practice: " + practice + ", Final mark: " + calculateFinalMark() + '}' + "\n";
    }

    public void display() {
        ls.stream().filter((selectedItem) -> (selectedItem.calculateFinalMark() >= 6)).forEachOrdered((selectedItem) -> {
            System.out.println(selectedItem);
        });
    }
}
