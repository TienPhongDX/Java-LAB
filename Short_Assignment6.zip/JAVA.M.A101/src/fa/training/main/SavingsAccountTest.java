/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 22 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.main;

import fa.training.entities.SavingsAccount;

public class SavingsAccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SavingsAccount saver1 = new SavingsAccount();
        SavingsAccount saver2 = new SavingsAccount();
        
        saver1.setSavingsBalance(2000);
        saver2.setSavingsBalance(3000);
        
        saver1.setAnnualInterestRate(0.04);
        saver2.setAnnualInterestRate(0.04);
        
        System.out.println("Monthly Interest");
        System.out.printf("Saver 1: %.3f $\n", saver1.calculateMonthlyInterest(saver1.getSavingsBalance(), saver1.getAnnualInterestRate()));
        System.out.printf("Saver 2: %.3f $\n", saver2.calculateMonthlyInterest(saver2.getSavingsBalance(), saver2.getAnnualInterestRate()));
        
        System.out.println("\nNew Balance");
        System.out.printf("Saver 1: %.3f $\n", saver1.getSavingsBalance());
        System.out.printf("Saver 2: %.3f $\n", saver2.getSavingsBalance());
        
        saver1.setAnnualInterestRate(0.05);
        saver2.setAnnualInterestRate(0.05);
        
        System.out.println("\nNext Month Interest");
        System.out.printf("Saver 1: %.3f $\n", saver1.calculateMonthlyInterest(saver1.getSavingsBalance(), saver1.getAnnualInterestRate()));
        System.out.printf("Saver 2: %.3f $\n", saver2.calculateMonthlyInterest(saver2.getSavingsBalance(), saver2.getAnnualInterestRate()));
        
        System.out.println("\nNew Balance");
        System.out.printf("Saver 1: %.3f $\n", saver1.getSavingsBalance());
        System.out.printf("Saver 2: %.3f $\n", saver2.getSavingsBalance());
	}

}
