/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.manager;

import fa.training.entities.Multimedia;
import fa.training.entities.Song;
import fa.training.entities.Video;
import fa.training.management.MultimediaManagement;

public class Manager {

	MultimediaManagement multimg = new MultimediaManagement();

	public static int MainMenu() {
		System.out.println("\nChoose function: ");
		System.out.println("1. Add a new video");
		System.out.println("2. Add a new song");
		System.out.println("3. Show all multimedia");
		System.out.println("4. Exit");
		int choice = Validator.checkinputInt();
		return choice;
	}

	public void mainMenuSelector() {
		while (true) {
			int menu = MainMenu();
			switch (menu) {
			case 1:
				Video video = new Video();
				video.createVideo();
				multimg.addMultiMedia(video);
				break;
			case 2:
				Song song = new Song();
				song.createSong();
				multimg.addMultiMedia(song);
				break;
			case 3:
				multimg.displayMultiMedia();
				break;
			case 4:

				return;
			}
		}
	}
}
