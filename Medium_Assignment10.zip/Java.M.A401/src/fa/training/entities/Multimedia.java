/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import fa.training.manager.Validator;

public abstract class Multimedia {
	private String name;
	private double duration;
	
	public Multimedia() {
		// TODO Auto-generated constructor stub
	}

	public Multimedia(String name, double duration) {
		super();
		this.name = name;
		this.duration = duration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}
	
	public void createMultimedia() {
		System.out.print("Input name: ");
		this.name = Validator.checkinputString();
		System.out.print("Input duration: ");
		this.duration = Validator.checkinputDouble();
	}
}
