/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

import fa.training.manager.Validator;

public class Song extends Multimedia{
	private String singer;
	
	public Song() {
		// TODO Auto-generated constructor stub
	}

	public Song(String name, double duration, String singer) {
		super(name, duration);
		this.singer = singer;
	}
	
	public void createSong() {
		createMultimedia();
		System.out.print("Input singer: ");
		this.singer = Validator.checkinputString();
	}

	@Override
	public String toString() {
		return "Song: " + super.getName() + "\t" + super.getDuration() + "\t" + this.singer ;
	}
	
	
}
