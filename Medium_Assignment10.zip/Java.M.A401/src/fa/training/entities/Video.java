/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.entities;

public class Video extends Multimedia{
	public Video() {
		// TODO Auto-generated constructor stub
	}

	public Video(String name, double duration) {
		super(name, duration);
		// TODO Auto-generated constructor stub
	}

	public void createVideo() {
		createMultimedia();
		
	}
	
	@Override
	public String toString() {
		return "Video: " + super.getName() + "\t" + super.getDuration();
	}
	
	
}
