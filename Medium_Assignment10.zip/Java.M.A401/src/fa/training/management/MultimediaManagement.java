/*
 * (C) Copyright 2021 TienPhong. All rights reserved
 * 
 * Author: ntpho
 * Date: 28 thg 1, 2021
 * Version: 1.0
 *
 */

package fa.training.management;

import java.util.ArrayList;
import java.util.List;

import fa.training.entities.Multimedia;
import fa.training.entities.Song;

public class MultimediaManagement {
	private List<Multimedia> listOfMultimedia;
	
	public MultimediaManagement() {
		// TODO Auto-generated constructor stub
		listOfMultimedia = new ArrayList<>();
	}

	public void displayMultiMedia() {
		System.out.println("----List of multimedia----");
		for (Multimedia multimedia : listOfMultimedia) {
//			if(multimedia instanceof Song) {
//				System.out.println(((Song)multimedia).toString());
//			} else {
				System.out.println(multimedia.toString());
//			}
		}
		System.out.println("\n--------------------------");
	}

	public void addMultiMedia(Multimedia multimedia) {
		this.listOfMultimedia.add(multimedia) ;
	}
	
	
}
